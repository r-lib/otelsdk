/*
 * Copyright The OpenTelemetry Authors
 * SPDX-License-Identifier: Apache-2.0
 */

/*
 * DO NOT EDIT, this is an Auto-generated file from:
 * buildscripts/semantic-convention/templates/registry/semantic_metrics-h.j2
 */

#pragma once

#include "opentelemetry/common/macros.h"
#include "opentelemetry/metrics/meter.h"
#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace semconv
{
namespace k8s
{

/**
  Deprecated, use @code k8s.container.cpu.limit.desired @endcode and @code
  k8s.container.cpu.limit.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.container.cpu.limit.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.container.cpu.limit.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sContainerCpuLimit =
    "k8s.container.cpu.limit";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sContainerCpuLimit =
    "Deprecated, use `k8s.container.cpu.limit.desired` and `k8s.container.cpu.limit.current` "
    "instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sContainerCpuLimit = "{cpu}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(
      kMetricK8sContainerCpuLimit, descrMetricK8sContainerCpuLimit, unitMetricK8sContainerCpuLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sContainerCpuLimit, descrMetricK8sContainerCpuLimit, unitMetricK8sContainerCpuLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sContainerCpuLimit, descrMetricK8sContainerCpuLimit, unitMetricK8sContainerCpuLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sContainerCpuLimit, descrMetricK8sContainerCpuLimit, unitMetricK8sContainerCpuLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Maximum CPU resource limit currently configured for a running container.
  <p>
  This metric aligns with the limit in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">K8s
  ContainerStatus</a> (status.containerStatuses[*].resources). Also see @code Actual Resources
  @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerCpuLimitCurrent = "k8s.container.cpu.limit.current";
static constexpr const char *descrMetricK8sContainerCpuLimitCurrent =
    "Maximum CPU resource limit currently configured for a running container.";
static constexpr const char *unitMetricK8sContainerCpuLimitCurrent = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerCpuLimitCurrent,
                                         descrMetricK8sContainerCpuLimitCurrent,
                                         unitMetricK8sContainerCpuLimitCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerCpuLimitCurrent,
                                          descrMetricK8sContainerCpuLimitCurrent,
                                          unitMetricK8sContainerCpuLimitCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerCpuLimitCurrent,
                                                   descrMetricK8sContainerCpuLimitCurrent,
                                                   unitMetricK8sContainerCpuLimitCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerCpuLimitCurrent,
                                                    descrMetricK8sContainerCpuLimitCurrent,
                                                    unitMetricK8sContainerCpuLimitCurrent);
}

/**
  Maximum CPU resource limit as defined by the container spec.
  <p>
  This metric aligns with the limit in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#container-v1-core">K8s
  Container</a> (spec.containers[*].resources). Also see @code Desired Resources @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerCpuLimitDesired = "k8s.container.cpu.limit.desired";
static constexpr const char *descrMetricK8sContainerCpuLimitDesired =
    "Maximum CPU resource limit as defined by the container spec.";
static constexpr const char *unitMetricK8sContainerCpuLimitDesired = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuLimitDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerCpuLimitDesired,
                                         descrMetricK8sContainerCpuLimitDesired,
                                         unitMetricK8sContainerCpuLimitDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuLimitDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerCpuLimitDesired,
                                          descrMetricK8sContainerCpuLimitDesired,
                                          unitMetricK8sContainerCpuLimitDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuLimitDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerCpuLimitDesired,
                                                   descrMetricK8sContainerCpuLimitDesired,
                                                   unitMetricK8sContainerCpuLimitDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuLimitDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerCpuLimitDesired,
                                                    descrMetricK8sContainerCpuLimitDesired,
                                                    unitMetricK8sContainerCpuLimitDesired);
}

/**
  The ratio of container CPU usage to its current CPU limit.
  <p>
  The current CPU limit reflects the actual resources applied to the container, as reported by
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">ContainerStatus</a>.
  The value range is [0.0,1.0]. A value of 1.0 means the container is using 100% of its actual CPU
  limit. If the CPU limit is not set, this metric SHOULD NOT be emitted for that container. <p>
  gauge
 */
static constexpr const char *kMetricK8sContainerCpuLimitUtilization =
    "k8s.container.cpu.limit.utilization";
static constexpr const char *descrMetricK8sContainerCpuLimitUtilization =
    "The ratio of container CPU usage to its current CPU limit.";
static constexpr const char *unitMetricK8sContainerCpuLimitUtilization = "1";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sContainerCpuLimitUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sContainerCpuLimitUtilization,
                                 descrMetricK8sContainerCpuLimitUtilization,
                                 unitMetricK8sContainerCpuLimitUtilization);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sContainerCpuLimitUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sContainerCpuLimitUtilization,
                                  descrMetricK8sContainerCpuLimitUtilization,
                                  unitMetricK8sContainerCpuLimitUtilization);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuLimitUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sContainerCpuLimitUtilization,
                                           descrMetricK8sContainerCpuLimitUtilization,
                                           unitMetricK8sContainerCpuLimitUtilization);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuLimitUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sContainerCpuLimitUtilization,
                                            descrMetricK8sContainerCpuLimitUtilization,
                                            unitMetricK8sContainerCpuLimitUtilization);
}

/**
  Deprecated, use @code k8s.container.cpu.request.desired @endcode and @code
  k8s.container.cpu.request.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.container.cpu.request.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.container.cpu.request.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sContainerCpuRequest =
    "k8s.container.cpu.request";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sContainerCpuRequest =
    "Deprecated, use `k8s.container.cpu.request.desired` and `k8s.container.cpu.request.current` "
    "instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sContainerCpuRequest = "{cpu}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerCpuRequest,
                                         descrMetricK8sContainerCpuRequest,
                                         unitMetricK8sContainerCpuRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerCpuRequest,
                                          descrMetricK8sContainerCpuRequest,
                                          unitMetricK8sContainerCpuRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerCpuRequest,
                                                   descrMetricK8sContainerCpuRequest,
                                                   unitMetricK8sContainerCpuRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerCpuRequest,
                                                    descrMetricK8sContainerCpuRequest,
                                                    unitMetricK8sContainerCpuRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  CPU resource requested currently configured for a running container.
  <p>
  This metric aligns with the request in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">K8s
  ContainerStatus</a> (status.containerStatuses[*].resources). Also see @code Actual Resources
  @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerCpuRequestCurrent =
    "k8s.container.cpu.request.current";
static constexpr const char *descrMetricK8sContainerCpuRequestCurrent =
    "CPU resource requested currently configured for a running container.";
static constexpr const char *unitMetricK8sContainerCpuRequestCurrent = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerCpuRequestCurrent,
                                         descrMetricK8sContainerCpuRequestCurrent,
                                         unitMetricK8sContainerCpuRequestCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerCpuRequestCurrent,
                                          descrMetricK8sContainerCpuRequestCurrent,
                                          unitMetricK8sContainerCpuRequestCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerCpuRequestCurrent,
                                                   descrMetricK8sContainerCpuRequestCurrent,
                                                   unitMetricK8sContainerCpuRequestCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerCpuRequestCurrent,
                                                    descrMetricK8sContainerCpuRequestCurrent,
                                                    unitMetricK8sContainerCpuRequestCurrent);
}

/**
  CPU resource requested as defined by the container spec.
  <p>
  This metric aligns with the request in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#container-v1-core">K8s
  Container</a> (spec.containers[*].resources). Also see @code Desired Resources @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerCpuRequestDesired =
    "k8s.container.cpu.request.desired";
static constexpr const char *descrMetricK8sContainerCpuRequestDesired =
    "CPU resource requested as defined by the container spec.";
static constexpr const char *unitMetricK8sContainerCpuRequestDesired = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerCpuRequestDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerCpuRequestDesired,
                                         descrMetricK8sContainerCpuRequestDesired,
                                         unitMetricK8sContainerCpuRequestDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerCpuRequestDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerCpuRequestDesired,
                                          descrMetricK8sContainerCpuRequestDesired,
                                          unitMetricK8sContainerCpuRequestDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuRequestDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerCpuRequestDesired,
                                                   descrMetricK8sContainerCpuRequestDesired,
                                                   unitMetricK8sContainerCpuRequestDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuRequestDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerCpuRequestDesired,
                                                    descrMetricK8sContainerCpuRequestDesired,
                                                    unitMetricK8sContainerCpuRequestDesired);
}

/**
  The ratio of container CPU usage to its current CPU request.
  <p>
  The current CPU request reflects the request applied to the running container, as reported by
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">ContainerStatus</a>.
  The value range is [0.0,1.0]. A value of 1.0 means the container is using 100% of its actual CPU
  request. If the CPU request is not set, this metric SHOULD NOT be emitted for that container. <p>
  gauge
 */
static constexpr const char *kMetricK8sContainerCpuRequestUtilization =
    "k8s.container.cpu.request.utilization";
static constexpr const char *descrMetricK8sContainerCpuRequestUtilization =
    "The ratio of container CPU usage to its current CPU request.";
static constexpr const char *unitMetricK8sContainerCpuRequestUtilization = "1";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sContainerCpuRequestUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sContainerCpuRequestUtilization,
                                 descrMetricK8sContainerCpuRequestUtilization,
                                 unitMetricK8sContainerCpuRequestUtilization);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sContainerCpuRequestUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sContainerCpuRequestUtilization,
                                  descrMetricK8sContainerCpuRequestUtilization,
                                  unitMetricK8sContainerCpuRequestUtilization);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerCpuRequestUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sContainerCpuRequestUtilization,
                                           descrMetricK8sContainerCpuRequestUtilization,
                                           unitMetricK8sContainerCpuRequestUtilization);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerCpuRequestUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sContainerCpuRequestUtilization,
                                            descrMetricK8sContainerCpuRequestUtilization,
                                            unitMetricK8sContainerCpuRequestUtilization);
}

/**
  Maximum ephemeral storage resource limit set for the container.
  <p>
  See
  https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core
  for details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerEphemeralStorageLimit =
    "k8s.container.ephemeral_storage.limit";
static constexpr const char *descrMetricK8sContainerEphemeralStorageLimit =
    "Maximum ephemeral storage resource limit set for the container.";
static constexpr const char *unitMetricK8sContainerEphemeralStorageLimit = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerEphemeralStorageLimit(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerEphemeralStorageLimit,
                                         descrMetricK8sContainerEphemeralStorageLimit,
                                         unitMetricK8sContainerEphemeralStorageLimit);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerEphemeralStorageLimit(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerEphemeralStorageLimit,
                                          descrMetricK8sContainerEphemeralStorageLimit,
                                          unitMetricK8sContainerEphemeralStorageLimit);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerEphemeralStorageLimit(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerEphemeralStorageLimit,
                                                   descrMetricK8sContainerEphemeralStorageLimit,
                                                   unitMetricK8sContainerEphemeralStorageLimit);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerEphemeralStorageLimit(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerEphemeralStorageLimit,
                                                    descrMetricK8sContainerEphemeralStorageLimit,
                                                    unitMetricK8sContainerEphemeralStorageLimit);
}

/**
  Ephemeral storage resource requested for the container.
  <p>
  See
  https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core
  for details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerEphemeralStorageRequest =
    "k8s.container.ephemeral_storage.request";
static constexpr const char *descrMetricK8sContainerEphemeralStorageRequest =
    "Ephemeral storage resource requested for the container.";
static constexpr const char *unitMetricK8sContainerEphemeralStorageRequest = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerEphemeralStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerEphemeralStorageRequest,
                                         descrMetricK8sContainerEphemeralStorageRequest,
                                         unitMetricK8sContainerEphemeralStorageRequest);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerEphemeralStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerEphemeralStorageRequest,
                                          descrMetricK8sContainerEphemeralStorageRequest,
                                          unitMetricK8sContainerEphemeralStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerEphemeralStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerEphemeralStorageRequest,
                                                   descrMetricK8sContainerEphemeralStorageRequest,
                                                   unitMetricK8sContainerEphemeralStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerEphemeralStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerEphemeralStorageRequest,
                                                    descrMetricK8sContainerEphemeralStorageRequest,
                                                    unitMetricK8sContainerEphemeralStorageRequest);
}

/**
  The ephemeral storage used by a container.
  <p>
  The value for this metric can be compared against @code
  metric.k8s.container.ephemeral_storage.request @endcode and @code
  metric.k8s.container.ephemeral_storage.limit @endcode. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerEphemeralStorageUsage =
    "k8s.container.ephemeral_storage.usage";
static constexpr const char *descrMetricK8sContainerEphemeralStorageUsage =
    "The ephemeral storage used by a container.";
static constexpr const char *unitMetricK8sContainerEphemeralStorageUsage = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerEphemeralStorageUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerEphemeralStorageUsage,
                                         descrMetricK8sContainerEphemeralStorageUsage,
                                         unitMetricK8sContainerEphemeralStorageUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerEphemeralStorageUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerEphemeralStorageUsage,
                                          descrMetricK8sContainerEphemeralStorageUsage,
                                          unitMetricK8sContainerEphemeralStorageUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerEphemeralStorageUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerEphemeralStorageUsage,
                                                   descrMetricK8sContainerEphemeralStorageUsage,
                                                   unitMetricK8sContainerEphemeralStorageUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerEphemeralStorageUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerEphemeralStorageUsage,
                                                    descrMetricK8sContainerEphemeralStorageUsage,
                                                    unitMetricK8sContainerEphemeralStorageUsage);
}

/**
  Deprecated, use @code k8s.container.memory.limit.desired @endcode and @code
  k8s.container.memory.limit.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.container.memory.limit.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.container.memory.limit.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sContainerMemoryLimit =
    "k8s.container.memory.limit";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sContainerMemoryLimit =
    "Deprecated, use `k8s.container.memory.limit.desired` and `k8s.container.memory.limit.current` "
    "instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sContainerMemoryLimit = "By";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryLimit,
                                         descrMetricK8sContainerMemoryLimit,
                                         unitMetricK8sContainerMemoryLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryLimit,
                                          descrMetricK8sContainerMemoryLimit,
                                          unitMetricK8sContainerMemoryLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryLimit,
                                                   descrMetricK8sContainerMemoryLimit,
                                                   unitMetricK8sContainerMemoryLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryLimit(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryLimit,
                                                    descrMetricK8sContainerMemoryLimit,
                                                    unitMetricK8sContainerMemoryLimit);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Maximum memory resource limit currently configured for a running container.
  <p>
  This metric aligns with the limit in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">K8s
  ContainerStatus</a> (status.containerStatuses[*].resources). Also see @code Actual Resources
  @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerMemoryLimitCurrent =
    "k8s.container.memory.limit.current";
static constexpr const char *descrMetricK8sContainerMemoryLimitCurrent =
    "Maximum memory resource limit currently configured for a running container.";
static constexpr const char *unitMetricK8sContainerMemoryLimitCurrent = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryLimitCurrent,
                                         descrMetricK8sContainerMemoryLimitCurrent,
                                         unitMetricK8sContainerMemoryLimitCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryLimitCurrent,
                                          descrMetricK8sContainerMemoryLimitCurrent,
                                          unitMetricK8sContainerMemoryLimitCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryLimitCurrent,
                                                   descrMetricK8sContainerMemoryLimitCurrent,
                                                   unitMetricK8sContainerMemoryLimitCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryLimitCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryLimitCurrent,
                                                    descrMetricK8sContainerMemoryLimitCurrent,
                                                    unitMetricK8sContainerMemoryLimitCurrent);
}

/**
  Maximum memory resource limit as defined by the container spec.
  <p>
  This metric aligns with the limit in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#container-v1-core">K8s
  Container</a> (spec.containers[*].resources). Also see @code Desired Resources @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerMemoryLimitDesired =
    "k8s.container.memory.limit.desired";
static constexpr const char *descrMetricK8sContainerMemoryLimitDesired =
    "Maximum memory resource limit as defined by the container spec.";
static constexpr const char *unitMetricK8sContainerMemoryLimitDesired = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryLimitDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryLimitDesired,
                                         descrMetricK8sContainerMemoryLimitDesired,
                                         unitMetricK8sContainerMemoryLimitDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryLimitDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryLimitDesired,
                                          descrMetricK8sContainerMemoryLimitDesired,
                                          unitMetricK8sContainerMemoryLimitDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryLimitDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryLimitDesired,
                                                   descrMetricK8sContainerMemoryLimitDesired,
                                                   unitMetricK8sContainerMemoryLimitDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryLimitDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryLimitDesired,
                                                    descrMetricK8sContainerMemoryLimitDesired,
                                                    unitMetricK8sContainerMemoryLimitDesired);
}

/**
  Deprecated, use @code k8s.container.memory.request.desired @endcode and @code
  k8s.container.memory.request.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.container.memory.request.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.container.memory.request.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sContainerMemoryRequest =
    "k8s.container.memory.request";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sContainerMemoryRequest =
    "Deprecated, use `k8s.container.memory.request.desired` and "
    "`k8s.container.memory.request.current` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sContainerMemoryRequest = "By";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryRequest,
                                         descrMetricK8sContainerMemoryRequest,
                                         unitMetricK8sContainerMemoryRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryRequest,
                                          descrMetricK8sContainerMemoryRequest,
                                          unitMetricK8sContainerMemoryRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryRequest,
                                                   descrMetricK8sContainerMemoryRequest,
                                                   unitMetricK8sContainerMemoryRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryRequest(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryRequest,
                                                    descrMetricK8sContainerMemoryRequest,
                                                    unitMetricK8sContainerMemoryRequest);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Memory resource request currently configured for a running container.
  <p>
  This metric aligns with the request in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">K8s
  ContainerStatus</a> (status.containerStatuses[*].resources). Also see @code Actual Resources
  @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerMemoryRequestCurrent =
    "k8s.container.memory.request.current";
static constexpr const char *descrMetricK8sContainerMemoryRequestCurrent =
    "Memory resource request currently configured for a running container.";
static constexpr const char *unitMetricK8sContainerMemoryRequestCurrent = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryRequestCurrent,
                                         descrMetricK8sContainerMemoryRequestCurrent,
                                         unitMetricK8sContainerMemoryRequestCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryRequestCurrent,
                                          descrMetricK8sContainerMemoryRequestCurrent,
                                          unitMetricK8sContainerMemoryRequestCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryRequestCurrent,
                                                   descrMetricK8sContainerMemoryRequestCurrent,
                                                   unitMetricK8sContainerMemoryRequestCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryRequestCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryRequestCurrent,
                                                    descrMetricK8sContainerMemoryRequestCurrent,
                                                    unitMetricK8sContainerMemoryRequestCurrent);
}

/**
  Memory resource requested as defined by the container spec.
  <p>
  This metric aligns with the request in the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core">@code
  resources @endcode</a> field of <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#container-v1-core">K8s
  Container</a> (spec.containers[*].resources). Also see @code Desired Resources @endcode in <a
  href="https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/">https://kubernetes.io/docs/tasks/configure-pod-container/resize-container-resources/</a>
  for more details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerMemoryRequestDesired =
    "k8s.container.memory.request.desired";
static constexpr const char *descrMetricK8sContainerMemoryRequestDesired =
    "Memory resource requested as defined by the container spec.";
static constexpr const char *unitMetricK8sContainerMemoryRequestDesired = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerMemoryRequestDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerMemoryRequestDesired,
                                         descrMetricK8sContainerMemoryRequestDesired,
                                         unitMetricK8sContainerMemoryRequestDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerMemoryRequestDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerMemoryRequestDesired,
                                          descrMetricK8sContainerMemoryRequestDesired,
                                          unitMetricK8sContainerMemoryRequestDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerMemoryRequestDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerMemoryRequestDesired,
                                                   descrMetricK8sContainerMemoryRequestDesired,
                                                   unitMetricK8sContainerMemoryRequestDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerMemoryRequestDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerMemoryRequestDesired,
                                                    descrMetricK8sContainerMemoryRequestDesired,
                                                    unitMetricK8sContainerMemoryRequestDesired);
}

/**
  Indicates whether the container is currently marked as ready to accept traffic, based on its
  readiness probe (1 = ready, 0 = not ready). <p> This metric SHOULD reflect the value of the @code
  ready @endcode field in the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#containerstatus-v1-core">K8s
  ContainerStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerReady = "k8s.container.ready";
static constexpr const char *descrMetricK8sContainerReady =
    "Indicates whether the container is currently marked as ready to accept traffic, based on its readiness probe (1 = ready, 0 = not ready).
    ";
    static constexpr const char *unitMetricK8sContainerReady = "{container}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerReady(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerReady, descrMetricK8sContainerReady,
                                         unitMetricK8sContainerReady);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerReady(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerReady, descrMetricK8sContainerReady,
                                          unitMetricK8sContainerReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerReady(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sContainerReady, descrMetricK8sContainerReady, unitMetricK8sContainerReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerReady(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sContainerReady, descrMetricK8sContainerReady, unitMetricK8sContainerReady);
}

/**
  Describes how many times the container has restarted (since the last counter reset).
  <p>
  This value is pulled directly from the K8s API and the value can go indefinitely high and be reset
  to 0 at any time depending on how your kubelet is configured to prune dead containers. It is best
  to not depend too much on the exact value but rather look at it as either == 0, in which case you
  can conclude there were no restarts in the recent past, or > 0, in which case you can conclude
  there were restarts in the recent past, and not try and analyze the value beyond that. <p>
  updowncounter
 */
static constexpr const char *kMetricK8sContainerRestartCount = "k8s.container.restart.count";
static constexpr const char *descrMetricK8sContainerRestartCount =
    "Describes how many times the container has restarted (since the last counter reset).";
static constexpr const char *unitMetricK8sContainerRestartCount = "{restart}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerRestartCount(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerRestartCount,
                                         descrMetricK8sContainerRestartCount,
                                         unitMetricK8sContainerRestartCount);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerRestartCount(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerRestartCount,
                                          descrMetricK8sContainerRestartCount,
                                          unitMetricK8sContainerRestartCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerRestartCount(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerRestartCount,
                                                   descrMetricK8sContainerRestartCount,
                                                   unitMetricK8sContainerRestartCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerRestartCount(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerRestartCount,
                                                    descrMetricK8sContainerRestartCount,
                                                    unitMetricK8sContainerRestartCount);
}

/**
  Describes the number of K8s containers that are currently in a state for a given reason.
  <p>
  All possible container state reasons will be reported at each time interval to avoid missing
  metrics. Only the value corresponding to the current state reason will be non-zero. <p>
  updowncounter
 */
static constexpr const char *kMetricK8sContainerStatusReason = "k8s.container.status.reason";
static constexpr const char *descrMetricK8sContainerStatusReason =
    "Describes the number of K8s containers that are currently in a state for a given reason.";
static constexpr const char *unitMetricK8sContainerStatusReason = "{container}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerStatusReason(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerStatusReason,
                                         descrMetricK8sContainerStatusReason,
                                         unitMetricK8sContainerStatusReason);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerStatusReason(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerStatusReason,
                                          descrMetricK8sContainerStatusReason,
                                          unitMetricK8sContainerStatusReason);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerStatusReason(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerStatusReason,
                                                   descrMetricK8sContainerStatusReason,
                                                   unitMetricK8sContainerStatusReason);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerStatusReason(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerStatusReason,
                                                    descrMetricK8sContainerStatusReason,
                                                    unitMetricK8sContainerStatusReason);
}

/**
  Describes the number of K8s containers that are currently in a given state.
  <p>
  All possible container states will be reported at each time interval to avoid missing metrics.
  Only the value corresponding to the current state will be non-zero.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sContainerStatusState = "k8s.container.status.state";
static constexpr const char *descrMetricK8sContainerStatusState =
    "Describes the number of K8s containers that are currently in a given state.";
static constexpr const char *unitMetricK8sContainerStatusState = "{container}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerStatusState(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerStatusState,
                                         descrMetricK8sContainerStatusState,
                                         unitMetricK8sContainerStatusState);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerStatusState(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerStatusState,
                                          descrMetricK8sContainerStatusState,
                                          unitMetricK8sContainerStatusState);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerStatusState(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerStatusState,
                                                   descrMetricK8sContainerStatusState,
                                                   unitMetricK8sContainerStatusState);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerStatusState(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerStatusState,
                                                    descrMetricK8sContainerStatusState,
                                                    unitMetricK8sContainerStatusState);
}

/**
  Maximum storage resource limit set for the container.
  <p>
  See
  https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core
  for details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerStorageLimit = "k8s.container.storage.limit";
static constexpr const char *descrMetricK8sContainerStorageLimit =
    "Maximum storage resource limit set for the container.";
static constexpr const char *unitMetricK8sContainerStorageLimit = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerStorageLimit(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerStorageLimit,
                                         descrMetricK8sContainerStorageLimit,
                                         unitMetricK8sContainerStorageLimit);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerStorageLimit(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerStorageLimit,
                                          descrMetricK8sContainerStorageLimit,
                                          unitMetricK8sContainerStorageLimit);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerStorageLimit(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerStorageLimit,
                                                   descrMetricK8sContainerStorageLimit,
                                                   unitMetricK8sContainerStorageLimit);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerStorageLimit(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerStorageLimit,
                                                    descrMetricK8sContainerStorageLimit,
                                                    unitMetricK8sContainerStorageLimit);
}

/**
  Storage resource requested for the container.
  <p>
  See
  https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcerequirements-v1-core
  for details. <p> updowncounter
 */
static constexpr const char *kMetricK8sContainerStorageRequest = "k8s.container.storage.request";
static constexpr const char *descrMetricK8sContainerStorageRequest =
    "Storage resource requested for the container.";
static constexpr const char *unitMetricK8sContainerStorageRequest = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sContainerStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sContainerStorageRequest,
                                         descrMetricK8sContainerStorageRequest,
                                         unitMetricK8sContainerStorageRequest);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sContainerStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sContainerStorageRequest,
                                          descrMetricK8sContainerStorageRequest,
                                          unitMetricK8sContainerStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sContainerStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sContainerStorageRequest,
                                                   descrMetricK8sContainerStorageRequest,
                                                   unitMetricK8sContainerStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sContainerStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sContainerStorageRequest,
                                                    descrMetricK8sContainerStorageRequest,
                                                    unitMetricK8sContainerStorageRequest);
}

/**
  Deprecated, use @code k8s.cronjob.job.active @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.cronjob.job.active @endcode.", "reason": "renamed", "renamed_to":
  "k8s.cronjob.job.active"} <p> This metric aligns with the @code active @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#cronjobstatus-v1-batch">K8s
  CronJobStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sCronjobActiveJobs =
    "k8s.cronjob.active_jobs";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sCronjobActiveJobs =
    "Deprecated, use `k8s.cronjob.job.active` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sCronjobActiveJobs = "{job}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sCronjobActiveJobs(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(
      kMetricK8sCronjobActiveJobs, descrMetricK8sCronjobActiveJobs, unitMetricK8sCronjobActiveJobs);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sCronjobActiveJobs(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sCronjobActiveJobs, descrMetricK8sCronjobActiveJobs, unitMetricK8sCronjobActiveJobs);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sCronjobActiveJobs(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sCronjobActiveJobs, descrMetricK8sCronjobActiveJobs, unitMetricK8sCronjobActiveJobs);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sCronjobActiveJobs(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sCronjobActiveJobs, descrMetricK8sCronjobActiveJobs, unitMetricK8sCronjobActiveJobs);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  The number of actively running jobs for a cronjob.
  <p>
  This metric aligns with the @code active @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#cronjobstatus-v1-batch">K8s
  CronJobStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sCronjobJobActive = "k8s.cronjob.job.active";
static constexpr const char *descrMetricK8sCronjobJobActive =
    "The number of actively running jobs for a cronjob.";
static constexpr const char *unitMetricK8sCronjobJobActive = "{job}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sCronjobJobActive(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sCronjobJobActive, descrMetricK8sCronjobJobActive,
                                         unitMetricK8sCronjobJobActive);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sCronjobJobActive(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sCronjobJobActive, descrMetricK8sCronjobJobActive, unitMetricK8sCronjobJobActive);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sCronjobJobActive(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sCronjobJobActive, descrMetricK8sCronjobJobActive, unitMetricK8sCronjobJobActive);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sCronjobJobActive(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sCronjobJobActive, descrMetricK8sCronjobJobActive, unitMetricK8sCronjobJobActive);
}

/**
  Deprecated, use @code k8s.daemonset.node.current_scheduled @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.daemonset.node.current_scheduled @endcode.", "reason": "renamed",
  "renamed_to": "k8s.daemonset.node.current_scheduled"} <p> This metric aligns with the @code
  currentNumberScheduled @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDaemonsetCurrentScheduledNodes =
    "k8s.daemonset.current_scheduled_nodes";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDaemonsetCurrentScheduledNodes =
    "Deprecated, use `k8s.daemonset.node.current_scheduled` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDaemonsetCurrentScheduledNodes =
    "{node}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetCurrentScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetCurrentScheduledNodes,
                                         descrMetricK8sDaemonsetCurrentScheduledNodes,
                                         unitMetricK8sDaemonsetCurrentScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetCurrentScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetCurrentScheduledNodes,
                                          descrMetricK8sDaemonsetCurrentScheduledNodes,
                                          unitMetricK8sDaemonsetCurrentScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetCurrentScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetCurrentScheduledNodes,
                                                   descrMetricK8sDaemonsetCurrentScheduledNodes,
                                                   unitMetricK8sDaemonsetCurrentScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetCurrentScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetCurrentScheduledNodes,
                                                    descrMetricK8sDaemonsetCurrentScheduledNodes,
                                                    unitMetricK8sDaemonsetCurrentScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.daemonset.node.desired_scheduled @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.daemonset.node.desired_scheduled @endcode.", "reason": "renamed",
  "renamed_to": "k8s.daemonset.node.desired_scheduled"} <p> This metric aligns with the @code
  desiredNumberScheduled @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDaemonsetDesiredScheduledNodes =
    "k8s.daemonset.desired_scheduled_nodes";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDaemonsetDesiredScheduledNodes =
    "Deprecated, use `k8s.daemonset.node.desired_scheduled` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDaemonsetDesiredScheduledNodes =
    "{node}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetDesiredScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetDesiredScheduledNodes,
                                         descrMetricK8sDaemonsetDesiredScheduledNodes,
                                         unitMetricK8sDaemonsetDesiredScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetDesiredScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetDesiredScheduledNodes,
                                          descrMetricK8sDaemonsetDesiredScheduledNodes,
                                          unitMetricK8sDaemonsetDesiredScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetDesiredScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetDesiredScheduledNodes,
                                                   descrMetricK8sDaemonsetDesiredScheduledNodes,
                                                   unitMetricK8sDaemonsetDesiredScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetDesiredScheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetDesiredScheduledNodes,
                                                    descrMetricK8sDaemonsetDesiredScheduledNodes,
                                                    unitMetricK8sDaemonsetDesiredScheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.daemonset.node.misscheduled @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.daemonset.node.misscheduled @endcode.", "reason": "renamed",
  "renamed_to": "k8s.daemonset.node.misscheduled"} <p> This metric aligns with the @code
  numberMisscheduled @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDaemonsetMisscheduledNodes =
    "k8s.daemonset.misscheduled_nodes";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDaemonsetMisscheduledNodes =
    "Deprecated, use `k8s.daemonset.node.misscheduled` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDaemonsetMisscheduledNodes =
    "{node}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetMisscheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetMisscheduledNodes,
                                         descrMetricK8sDaemonsetMisscheduledNodes,
                                         unitMetricK8sDaemonsetMisscheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetMisscheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetMisscheduledNodes,
                                          descrMetricK8sDaemonsetMisscheduledNodes,
                                          unitMetricK8sDaemonsetMisscheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetMisscheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetMisscheduledNodes,
                                                   descrMetricK8sDaemonsetMisscheduledNodes,
                                                   unitMetricK8sDaemonsetMisscheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetMisscheduledNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetMisscheduledNodes,
                                                    descrMetricK8sDaemonsetMisscheduledNodes,
                                                    unitMetricK8sDaemonsetMisscheduledNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Number of nodes that are running at least 1 daemon pod and are supposed to run the daemon pod.
  <p>
  This metric aligns with the @code currentNumberScheduled @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDaemonsetNodeCurrentScheduled =
    "k8s.daemonset.node.current_scheduled";
static constexpr const char *descrMetricK8sDaemonsetNodeCurrentScheduled =
    "Number of nodes that are running at least 1 daemon pod and are supposed to run the daemon "
    "pod.";
static constexpr const char *unitMetricK8sDaemonsetNodeCurrentScheduled = "{node}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetNodeCurrentScheduled(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetNodeCurrentScheduled,
                                         descrMetricK8sDaemonsetNodeCurrentScheduled,
                                         unitMetricK8sDaemonsetNodeCurrentScheduled);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetNodeCurrentScheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetNodeCurrentScheduled,
                                          descrMetricK8sDaemonsetNodeCurrentScheduled,
                                          unitMetricK8sDaemonsetNodeCurrentScheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetNodeCurrentScheduled(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetNodeCurrentScheduled,
                                                   descrMetricK8sDaemonsetNodeCurrentScheduled,
                                                   unitMetricK8sDaemonsetNodeCurrentScheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetNodeCurrentScheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetNodeCurrentScheduled,
                                                    descrMetricK8sDaemonsetNodeCurrentScheduled,
                                                    unitMetricK8sDaemonsetNodeCurrentScheduled);
}

/**
  Number of nodes that should be running the daemon pod (including nodes currently running the
  daemon pod). <p> This metric aligns with the @code desiredNumberScheduled @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDaemonsetNodeDesiredScheduled =
    "k8s.daemonset.node.desired_scheduled";
static constexpr const char *descrMetricK8sDaemonsetNodeDesiredScheduled =
    "Number of nodes that should be running the daemon pod (including nodes currently running the "
    "daemon pod).";
static constexpr const char *unitMetricK8sDaemonsetNodeDesiredScheduled = "{node}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetNodeDesiredScheduled(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetNodeDesiredScheduled,
                                         descrMetricK8sDaemonsetNodeDesiredScheduled,
                                         unitMetricK8sDaemonsetNodeDesiredScheduled);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetNodeDesiredScheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetNodeDesiredScheduled,
                                          descrMetricK8sDaemonsetNodeDesiredScheduled,
                                          unitMetricK8sDaemonsetNodeDesiredScheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetNodeDesiredScheduled(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetNodeDesiredScheduled,
                                                   descrMetricK8sDaemonsetNodeDesiredScheduled,
                                                   unitMetricK8sDaemonsetNodeDesiredScheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetNodeDesiredScheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetNodeDesiredScheduled,
                                                    descrMetricK8sDaemonsetNodeDesiredScheduled,
                                                    unitMetricK8sDaemonsetNodeDesiredScheduled);
}

/**
  Number of nodes that are running the daemon pod, but are not supposed to run the daemon pod.
  <p>
  This metric aligns with the @code numberMisscheduled @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDaemonsetNodeMisscheduled =
    "k8s.daemonset.node.misscheduled";
static constexpr const char *descrMetricK8sDaemonsetNodeMisscheduled =
    "Number of nodes that are running the daemon pod, but are not supposed to run the daemon pod.";
static constexpr const char *unitMetricK8sDaemonsetNodeMisscheduled = "{node}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetNodeMisscheduled(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetNodeMisscheduled,
                                         descrMetricK8sDaemonsetNodeMisscheduled,
                                         unitMetricK8sDaemonsetNodeMisscheduled);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetNodeMisscheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetNodeMisscheduled,
                                          descrMetricK8sDaemonsetNodeMisscheduled,
                                          unitMetricK8sDaemonsetNodeMisscheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetNodeMisscheduled(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetNodeMisscheduled,
                                                   descrMetricK8sDaemonsetNodeMisscheduled,
                                                   unitMetricK8sDaemonsetNodeMisscheduled);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetNodeMisscheduled(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetNodeMisscheduled,
                                                    descrMetricK8sDaemonsetNodeMisscheduled,
                                                    unitMetricK8sDaemonsetNodeMisscheduled);
}

/**
  Number of nodes that should be running the daemon pod and have one or more of the daemon pod
  running and ready. <p> This metric aligns with the @code numberReady @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDaemonsetNodeReady = "k8s.daemonset.node.ready";
static constexpr const char *descrMetricK8sDaemonsetNodeReady =
    "Number of nodes that should be running the daemon pod and have one or more of the daemon pod "
    "running and ready.";
static constexpr const char *unitMetricK8sDaemonsetNodeReady = "{node}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetNodeReady(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetNodeReady,
                                         descrMetricK8sDaemonsetNodeReady,
                                         unitMetricK8sDaemonsetNodeReady);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetNodeReady(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetNodeReady,
                                          descrMetricK8sDaemonsetNodeReady,
                                          unitMetricK8sDaemonsetNodeReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetNodeReady(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetNodeReady,
                                                   descrMetricK8sDaemonsetNodeReady,
                                                   unitMetricK8sDaemonsetNodeReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetNodeReady(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetNodeReady,
                                                    descrMetricK8sDaemonsetNodeReady,
                                                    unitMetricK8sDaemonsetNodeReady);
}

/**
  Deprecated, use @code k8s.daemonset.node.ready @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.daemonset.node.ready @endcode.", "reason": "renamed",
  "renamed_to": "k8s.daemonset.node.ready"} <p> This metric aligns with the @code numberReady
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#daemonsetstatus-v1-apps">K8s
  DaemonSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDaemonsetReadyNodes =
    "k8s.daemonset.ready_nodes";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDaemonsetReadyNodes =
    "Deprecated, use `k8s.daemonset.node.ready` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDaemonsetReadyNodes = "{node}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDaemonsetReadyNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDaemonsetReadyNodes,
                                         descrMetricK8sDaemonsetReadyNodes,
                                         unitMetricK8sDaemonsetReadyNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDaemonsetReadyNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDaemonsetReadyNodes,
                                          descrMetricK8sDaemonsetReadyNodes,
                                          unitMetricK8sDaemonsetReadyNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDaemonsetReadyNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDaemonsetReadyNodes,
                                                   descrMetricK8sDaemonsetReadyNodes,
                                                   unitMetricK8sDaemonsetReadyNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDaemonsetReadyNodes(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDaemonsetReadyNodes,
                                                    descrMetricK8sDaemonsetReadyNodes,
                                                    unitMetricK8sDaemonsetReadyNodes);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.deployment.pod.available @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.deployment.pod.available @endcode.", "reason": "renamed",
  "renamed_to": "k8s.deployment.pod.available"} <p> This metric aligns with the @code
  availableReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#deploymentstatus-v1-apps">K8s
  DeploymentStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDeploymentAvailablePods =
    "k8s.deployment.available_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDeploymentAvailablePods =
    "Deprecated, use `k8s.deployment.pod.available` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDeploymentAvailablePods =
    "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDeploymentAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDeploymentAvailablePods,
                                         descrMetricK8sDeploymentAvailablePods,
                                         unitMetricK8sDeploymentAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDeploymentAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDeploymentAvailablePods,
                                          descrMetricK8sDeploymentAvailablePods,
                                          unitMetricK8sDeploymentAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDeploymentAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDeploymentAvailablePods,
                                                   descrMetricK8sDeploymentAvailablePods,
                                                   unitMetricK8sDeploymentAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDeploymentAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDeploymentAvailablePods,
                                                    descrMetricK8sDeploymentAvailablePods,
                                                    unitMetricK8sDeploymentAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.deployment.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.deployment.pod.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.deployment.pod.desired"} <p> This metric aligns with the @code replicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#deploymentspec-v1-apps">K8s
  DeploymentSpec</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sDeploymentDesiredPods =
    "k8s.deployment.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sDeploymentDesiredPods =
    "Deprecated, use `k8s.deployment.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sDeploymentDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDeploymentDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sDeploymentDesiredPods,
                                         descrMetricK8sDeploymentDesiredPods,
                                         unitMetricK8sDeploymentDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDeploymentDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sDeploymentDesiredPods,
                                          descrMetricK8sDeploymentDesiredPods,
                                          unitMetricK8sDeploymentDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDeploymentDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDeploymentDesiredPods,
                                                   descrMetricK8sDeploymentDesiredPods,
                                                   unitMetricK8sDeploymentDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDeploymentDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDeploymentDesiredPods,
                                                    descrMetricK8sDeploymentDesiredPods,
                                                    unitMetricK8sDeploymentDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Total number of available replica pods (ready for at least minReadySeconds) targeted by this
  deployment. <p> This metric aligns with the @code availableReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#deploymentstatus-v1-apps">K8s
  DeploymentStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDeploymentPodAvailable = "k8s.deployment.pod.available";
static constexpr const char *descrMetricK8sDeploymentPodAvailable =
    "Total number of available replica pods (ready for at least minReadySeconds) targeted by this "
    "deployment.";
static constexpr const char *unitMetricK8sDeploymentPodAvailable = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDeploymentPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDeploymentPodAvailable,
                                         descrMetricK8sDeploymentPodAvailable,
                                         unitMetricK8sDeploymentPodAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDeploymentPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDeploymentPodAvailable,
                                          descrMetricK8sDeploymentPodAvailable,
                                          unitMetricK8sDeploymentPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDeploymentPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDeploymentPodAvailable,
                                                   descrMetricK8sDeploymentPodAvailable,
                                                   unitMetricK8sDeploymentPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDeploymentPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDeploymentPodAvailable,
                                                    descrMetricK8sDeploymentPodAvailable,
                                                    unitMetricK8sDeploymentPodAvailable);
}

/**
  Number of desired replica pods in this deployment.
  <p>
  This metric aligns with the @code replicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#deploymentspec-v1-apps">K8s
  DeploymentSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sDeploymentPodDesired = "k8s.deployment.pod.desired";
static constexpr const char *descrMetricK8sDeploymentPodDesired =
    "Number of desired replica pods in this deployment.";
static constexpr const char *unitMetricK8sDeploymentPodDesired = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sDeploymentPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sDeploymentPodDesired,
                                         descrMetricK8sDeploymentPodDesired,
                                         unitMetricK8sDeploymentPodDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sDeploymentPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sDeploymentPodDesired,
                                          descrMetricK8sDeploymentPodDesired,
                                          unitMetricK8sDeploymentPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sDeploymentPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sDeploymentPodDesired,
                                                   descrMetricK8sDeploymentPodDesired,
                                                   unitMetricK8sDeploymentPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sDeploymentPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sDeploymentPodDesired,
                                                    descrMetricK8sDeploymentPodDesired,
                                                    unitMetricK8sDeploymentPodDesired);
}

/**
  Deprecated, use @code k8s.hpa.pod.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.hpa.pod.current @endcode.", "reason": "renamed", "renamed_to":
  "k8s.hpa.pod.current"} <p> This metric aligns with the @code currentReplicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerstatus-v2-autoscaling">K8s
  HorizontalPodAutoscalerStatus</a> <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sHpaCurrentPods =
    "k8s.hpa.current_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sHpaCurrentPods =
    "Deprecated, use `k8s.hpa.pod.current` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sHpaCurrentPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaCurrentPods, descrMetricK8sHpaCurrentPods,
                                         unitMetricK8sHpaCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaCurrentPods, descrMetricK8sHpaCurrentPods,
                                          unitMetricK8sHpaCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sHpaCurrentPods, descrMetricK8sHpaCurrentPods, unitMetricK8sHpaCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sHpaCurrentPods, descrMetricK8sHpaCurrentPods, unitMetricK8sHpaCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.hpa.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.hpa.pod.desired @endcode.", "reason": "renamed", "renamed_to":
  "k8s.hpa.pod.desired"} <p> This metric aligns with the @code desiredReplicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerstatus-v2-autoscaling">K8s
  HorizontalPodAutoscalerStatus</a> <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sHpaDesiredPods =
    "k8s.hpa.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sHpaDesiredPods =
    "Deprecated, use `k8s.hpa.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sHpaDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaDesiredPods, descrMetricK8sHpaDesiredPods,
                                         unitMetricK8sHpaDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaDesiredPods, descrMetricK8sHpaDesiredPods,
                                          unitMetricK8sHpaDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sHpaDesiredPods, descrMetricK8sHpaDesiredPods, unitMetricK8sHpaDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sHpaDesiredPods, descrMetricK8sHpaDesiredPods, unitMetricK8sHpaDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.hpa.pod.max @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.hpa.pod.max @endcode.", "reason": "renamed", "renamed_to":
  "k8s.hpa.pod.max"} <p> This metric aligns with the @code maxReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerspec-v2-autoscaling">K8s
  HorizontalPodAutoscalerSpec</a> <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sHpaMaxPods = "k8s.hpa.max_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sHpaMaxPods =
    "Deprecated, use `k8s.hpa.pod.max` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sHpaMaxPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaMaxPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaMaxPods, descrMetricK8sHpaMaxPods,
                                         unitMetricK8sHpaMaxPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaMaxPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaMaxPods, descrMetricK8sHpaMaxPods,
                                          unitMetricK8sHpaMaxPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaMaxPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sHpaMaxPods, descrMetricK8sHpaMaxPods,
                                                   unitMetricK8sHpaMaxPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaMaxPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sHpaMaxPods, descrMetricK8sHpaMaxPods,
                                                    unitMetricK8sHpaMaxPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Target average utilization, in percentage, for CPU resource in HPA config.
  <p>
  This metric aligns with the @code averageUtilization @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#metrictarget-v2-autoscaling">K8s
  HPA MetricTarget</a>. If the type of the metric is <a
  href="https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#support-for-metrics-apis">@code
  ContainerResource @endcode</a>, the @code k8s.container.name @endcode attribute MUST be set to
  identify the specific container within the pod to which the metric applies. <p> gauge
 */
static constexpr const char *kMetricK8sHpaMetricTargetCpuAverageUtilization =
    "k8s.hpa.metric.target.cpu.average_utilization";
static constexpr const char *descrMetricK8sHpaMetricTargetCpuAverageUtilization =
    "Target average utilization, in percentage, for CPU resource in HPA config.";
static constexpr const char *unitMetricK8sHpaMetricTargetCpuAverageUtilization = "1";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sHpaMetricTargetCpuAverageUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sHpaMetricTargetCpuAverageUtilization,
                                 descrMetricK8sHpaMetricTargetCpuAverageUtilization,
                                 unitMetricK8sHpaMetricTargetCpuAverageUtilization);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sHpaMetricTargetCpuAverageUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sHpaMetricTargetCpuAverageUtilization,
                                  descrMetricK8sHpaMetricTargetCpuAverageUtilization,
                                  unitMetricK8sHpaMetricTargetCpuAverageUtilization);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaMetricTargetCpuAverageUtilization(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sHpaMetricTargetCpuAverageUtilization,
                                           descrMetricK8sHpaMetricTargetCpuAverageUtilization,
                                           unitMetricK8sHpaMetricTargetCpuAverageUtilization);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaMetricTargetCpuAverageUtilization(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sHpaMetricTargetCpuAverageUtilization,
                                            descrMetricK8sHpaMetricTargetCpuAverageUtilization,
                                            unitMetricK8sHpaMetricTargetCpuAverageUtilization);
}

/**
  Target average value for CPU resource in HPA config.
  <p>
  This metric aligns with the @code averageValue @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#metrictarget-v2-autoscaling">K8s
  HPA MetricTarget</a>. If the type of the metric is <a
  href="https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#support-for-metrics-apis">@code
  ContainerResource @endcode</a>, the @code k8s.container.name @endcode attribute MUST be set to
  identify the specific container within the pod to which the metric applies. <p> gauge
 */
static constexpr const char *kMetricK8sHpaMetricTargetCpuAverageValue =
    "k8s.hpa.metric.target.cpu.average_value";
static constexpr const char *descrMetricK8sHpaMetricTargetCpuAverageValue =
    "Target average value for CPU resource in HPA config.";
static constexpr const char *unitMetricK8sHpaMetricTargetCpuAverageValue = "{cpu}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sHpaMetricTargetCpuAverageValue(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sHpaMetricTargetCpuAverageValue,
                                 descrMetricK8sHpaMetricTargetCpuAverageValue,
                                 unitMetricK8sHpaMetricTargetCpuAverageValue);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sHpaMetricTargetCpuAverageValue(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sHpaMetricTargetCpuAverageValue,
                                  descrMetricK8sHpaMetricTargetCpuAverageValue,
                                  unitMetricK8sHpaMetricTargetCpuAverageValue);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaMetricTargetCpuAverageValue(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sHpaMetricTargetCpuAverageValue,
                                           descrMetricK8sHpaMetricTargetCpuAverageValue,
                                           unitMetricK8sHpaMetricTargetCpuAverageValue);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaMetricTargetCpuAverageValue(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sHpaMetricTargetCpuAverageValue,
                                            descrMetricK8sHpaMetricTargetCpuAverageValue,
                                            unitMetricK8sHpaMetricTargetCpuAverageValue);
}

/**
  Target value for CPU resource in HPA config.
  <p>
  This metric aligns with the @code value @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#metrictarget-v2-autoscaling">K8s
  HPA MetricTarget</a>. If the type of the metric is <a
  href="https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/#support-for-metrics-apis">@code
  ContainerResource @endcode</a>, the @code k8s.container.name @endcode attribute MUST be set to
  identify the specific container within the pod to which the metric applies. <p> gauge
 */
static constexpr const char *kMetricK8sHpaMetricTargetCpuValue = "k8s.hpa.metric.target.cpu.value";
static constexpr const char *descrMetricK8sHpaMetricTargetCpuValue =
    "Target value for CPU resource in HPA config.";
static constexpr const char *unitMetricK8sHpaMetricTargetCpuValue = "{cpu}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sHpaMetricTargetCpuValue(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sHpaMetricTargetCpuValue,
                                 descrMetricK8sHpaMetricTargetCpuValue,
                                 unitMetricK8sHpaMetricTargetCpuValue);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sHpaMetricTargetCpuValue(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sHpaMetricTargetCpuValue,
                                  descrMetricK8sHpaMetricTargetCpuValue,
                                  unitMetricK8sHpaMetricTargetCpuValue);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaMetricTargetCpuValue(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sHpaMetricTargetCpuValue,
                                           descrMetricK8sHpaMetricTargetCpuValue,
                                           unitMetricK8sHpaMetricTargetCpuValue);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaMetricTargetCpuValue(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sHpaMetricTargetCpuValue,
                                            descrMetricK8sHpaMetricTargetCpuValue,
                                            unitMetricK8sHpaMetricTargetCpuValue);
}

/**
  Deprecated, use @code k8s.hpa.pod.min @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.hpa.pod.min @endcode.", "reason": "renamed", "renamed_to":
  "k8s.hpa.pod.min"} <p> This metric aligns with the @code minReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerspec-v2-autoscaling">K8s
  HorizontalPodAutoscalerSpec</a> <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sHpaMinPods = "k8s.hpa.min_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sHpaMinPods =
    "Deprecated, use `k8s.hpa.pod.min` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sHpaMinPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaMinPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaMinPods, descrMetricK8sHpaMinPods,
                                         unitMetricK8sHpaMinPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaMinPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaMinPods, descrMetricK8sHpaMinPods,
                                          unitMetricK8sHpaMinPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaMinPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sHpaMinPods, descrMetricK8sHpaMinPods,
                                                   unitMetricK8sHpaMinPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaMinPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sHpaMinPods, descrMetricK8sHpaMinPods,
                                                    unitMetricK8sHpaMinPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Current number of replica pods managed by this horizontal pod autoscaler, as last seen by the
  autoscaler. <p> This metric aligns with the @code currentReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerstatus-v2-autoscaling">K8s
  HorizontalPodAutoscalerStatus</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sHpaPodCurrent = "k8s.hpa.pod.current";
static constexpr const char *descrMetricK8sHpaPodCurrent =
    "Current number of replica pods managed by this horizontal pod autoscaler, as last seen by the "
    "autoscaler.";
static constexpr const char *unitMetricK8sHpaPodCurrent = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaPodCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaPodCurrent, descrMetricK8sHpaPodCurrent,
                                         unitMetricK8sHpaPodCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaPodCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaPodCurrent, descrMetricK8sHpaPodCurrent,
                                          unitMetricK8sHpaPodCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaPodCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sHpaPodCurrent, descrMetricK8sHpaPodCurrent, unitMetricK8sHpaPodCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaPodCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sHpaPodCurrent, descrMetricK8sHpaPodCurrent, unitMetricK8sHpaPodCurrent);
}

/**
  Desired number of replica pods managed by this horizontal pod autoscaler, as last calculated by
  the autoscaler. <p> This metric aligns with the @code desiredReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerstatus-v2-autoscaling">K8s
  HorizontalPodAutoscalerStatus</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sHpaPodDesired = "k8s.hpa.pod.desired";
static constexpr const char *descrMetricK8sHpaPodDesired =
    "Desired number of replica pods managed by this horizontal pod autoscaler, as last calculated "
    "by the autoscaler.";
static constexpr const char *unitMetricK8sHpaPodDesired = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sHpaPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaPodDesired, descrMetricK8sHpaPodDesired,
                                         unitMetricK8sHpaPodDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sHpaPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaPodDesired, descrMetricK8sHpaPodDesired,
                                          unitMetricK8sHpaPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sHpaPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sHpaPodDesired, descrMetricK8sHpaPodDesired, unitMetricK8sHpaPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sHpaPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sHpaPodDesired, descrMetricK8sHpaPodDesired, unitMetricK8sHpaPodDesired);
}

/**
  The upper limit for the number of replica pods to which the autoscaler can scale up.
  <p>
  This metric aligns with the @code maxReplicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerspec-v2-autoscaling">K8s
  HorizontalPodAutoscalerSpec</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sHpaPodMax = "k8s.hpa.pod.max";
static constexpr const char *descrMetricK8sHpaPodMax =
    "The upper limit for the number of replica pods to which the autoscaler can scale up.";
static constexpr const char *unitMetricK8sHpaPodMax = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>> CreateSyncInt64MetricK8sHpaPodMax(
    metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaPodMax, descrMetricK8sHpaPodMax,
                                         unitMetricK8sHpaPodMax);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>> CreateSyncDoubleMetricK8sHpaPodMax(
    metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaPodMax, descrMetricK8sHpaPodMax,
                                          unitMetricK8sHpaPodMax);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sHpaPodMax(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sHpaPodMax, descrMetricK8sHpaPodMax,
                                                   unitMetricK8sHpaPodMax);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncDoubleMetricK8sHpaPodMax(
    metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sHpaPodMax, descrMetricK8sHpaPodMax,
                                                    unitMetricK8sHpaPodMax);
}

/**
  The lower limit for the number of replica pods to which the autoscaler can scale down.
  <p>
  This metric aligns with the @code minReplicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#horizontalpodautoscalerspec-v2-autoscaling">K8s
  HorizontalPodAutoscalerSpec</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sHpaPodMin = "k8s.hpa.pod.min";
static constexpr const char *descrMetricK8sHpaPodMin =
    "The lower limit for the number of replica pods to which the autoscaler can scale down.";
static constexpr const char *unitMetricK8sHpaPodMin = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>> CreateSyncInt64MetricK8sHpaPodMin(
    metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sHpaPodMin, descrMetricK8sHpaPodMin,
                                         unitMetricK8sHpaPodMin);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>> CreateSyncDoubleMetricK8sHpaPodMin(
    metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sHpaPodMin, descrMetricK8sHpaPodMin,
                                          unitMetricK8sHpaPodMin);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sHpaPodMin(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sHpaPodMin, descrMetricK8sHpaPodMin,
                                                   unitMetricK8sHpaPodMin);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncDoubleMetricK8sHpaPodMin(
    metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sHpaPodMin, descrMetricK8sHpaPodMin,
                                                    unitMetricK8sHpaPodMin);
}

/**
  Deprecated, use @code k8s.job.pod.active @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.job.pod.active @endcode.", "reason": "renamed", "renamed_to":
  "k8s.job.pod.active"} <p> This metric aligns with the @code active @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sJobActivePods =
    "k8s.job.active_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sJobActivePods =
    "Deprecated, use `k8s.job.pod.active` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sJobActivePods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobActivePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sJobActivePods, descrMetricK8sJobActivePods,
                                         unitMetricK8sJobActivePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobActivePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobActivePods, descrMetricK8sJobActivePods,
                                          unitMetricK8sJobActivePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobActivePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobActivePods, descrMetricK8sJobActivePods, unitMetricK8sJobActivePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobActivePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobActivePods, descrMetricK8sJobActivePods, unitMetricK8sJobActivePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.job.pod.desired_successful @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.job.pod.desired_successful @endcode.", "reason": "renamed",
  "renamed_to": "k8s.job.pod.desired_successful"} <p> This metric aligns with the @code completions
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobspec-v1-batch">K8s
  JobSpec</a>.. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sJobDesiredSuccessfulPods =
    "k8s.job.desired_successful_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sJobDesiredSuccessfulPods =
    "Deprecated, use `k8s.job.pod.desired_successful` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sJobDesiredSuccessfulPods =
    "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobDesiredSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sJobDesiredSuccessfulPods,
                                         descrMetricK8sJobDesiredSuccessfulPods,
                                         unitMetricK8sJobDesiredSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobDesiredSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobDesiredSuccessfulPods,
                                          descrMetricK8sJobDesiredSuccessfulPods,
                                          unitMetricK8sJobDesiredSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobDesiredSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sJobDesiredSuccessfulPods,
                                                   descrMetricK8sJobDesiredSuccessfulPods,
                                                   unitMetricK8sJobDesiredSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobDesiredSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sJobDesiredSuccessfulPods,
                                                    descrMetricK8sJobDesiredSuccessfulPods,
                                                    unitMetricK8sJobDesiredSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.job.pod.failed @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.job.pod.failed @endcode.", "reason": "renamed", "renamed_to":
  "k8s.job.pod.failed"} <p> This metric aligns with the @code failed @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sJobFailedPods =
    "k8s.job.failed_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sJobFailedPods =
    "Deprecated, use `k8s.job.pod.failed` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sJobFailedPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobFailedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sJobFailedPods, descrMetricK8sJobFailedPods,
                                         unitMetricK8sJobFailedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobFailedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobFailedPods, descrMetricK8sJobFailedPods,
                                          unitMetricK8sJobFailedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobFailedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobFailedPods, descrMetricK8sJobFailedPods, unitMetricK8sJobFailedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobFailedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobFailedPods, descrMetricK8sJobFailedPods, unitMetricK8sJobFailedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.job.pod.max_parallel @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.job.pod.max_parallel @endcode.", "reason": "renamed",
  "renamed_to": "k8s.job.pod.max_parallel"} <p> This metric aligns with the @code parallelism
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobspec-v1-batch">K8s
  JobSpec</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sJobMaxParallelPods =
    "k8s.job.max_parallel_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sJobMaxParallelPods =
    "Deprecated, use `k8s.job.pod.max_parallel` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sJobMaxParallelPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobMaxParallelPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sJobMaxParallelPods,
                                         descrMetricK8sJobMaxParallelPods,
                                         unitMetricK8sJobMaxParallelPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobMaxParallelPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobMaxParallelPods,
                                          descrMetricK8sJobMaxParallelPods,
                                          unitMetricK8sJobMaxParallelPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobMaxParallelPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sJobMaxParallelPods,
                                                   descrMetricK8sJobMaxParallelPods,
                                                   unitMetricK8sJobMaxParallelPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobMaxParallelPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sJobMaxParallelPods,
                                                    descrMetricK8sJobMaxParallelPods,
                                                    unitMetricK8sJobMaxParallelPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  The number of pending and actively running pods for a job.
  <p>
  This metric aligns with the @code active @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sJobPodActive = "k8s.job.pod.active";
static constexpr const char *descrMetricK8sJobPodActive =
    "The number of pending and actively running pods for a job.";
static constexpr const char *unitMetricK8sJobPodActive = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobPodActive(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sJobPodActive, descrMetricK8sJobPodActive,
                                         unitMetricK8sJobPodActive);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobPodActive(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobPodActive, descrMetricK8sJobPodActive,
                                          unitMetricK8sJobPodActive);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobPodActive(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobPodActive, descrMetricK8sJobPodActive, unitMetricK8sJobPodActive);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobPodActive(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobPodActive, descrMetricK8sJobPodActive, unitMetricK8sJobPodActive);
}

/**
  The desired number of successfully finished pods the job should be run with.
  <p>
  This metric aligns with the @code completions @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobspec-v1-batch">K8s
  JobSpec</a>.. <p> updowncounter
 */
static constexpr const char *kMetricK8sJobPodDesiredSuccessful = "k8s.job.pod.desired_successful";
static constexpr const char *descrMetricK8sJobPodDesiredSuccessful =
    "The desired number of successfully finished pods the job should be run with.";
static constexpr const char *unitMetricK8sJobPodDesiredSuccessful = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobPodDesiredSuccessful(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sJobPodDesiredSuccessful,
                                         descrMetricK8sJobPodDesiredSuccessful,
                                         unitMetricK8sJobPodDesiredSuccessful);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobPodDesiredSuccessful(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobPodDesiredSuccessful,
                                          descrMetricK8sJobPodDesiredSuccessful,
                                          unitMetricK8sJobPodDesiredSuccessful);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobPodDesiredSuccessful(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sJobPodDesiredSuccessful,
                                                   descrMetricK8sJobPodDesiredSuccessful,
                                                   unitMetricK8sJobPodDesiredSuccessful);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobPodDesiredSuccessful(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sJobPodDesiredSuccessful,
                                                    descrMetricK8sJobPodDesiredSuccessful,
                                                    unitMetricK8sJobPodDesiredSuccessful);
}

/**
  The number of pods which reached phase Failed for a job.
  <p>
  This metric aligns with the @code failed @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sJobPodFailed = "k8s.job.pod.failed";
static constexpr const char *descrMetricK8sJobPodFailed =
    "The number of pods which reached phase Failed for a job.";
static constexpr const char *unitMetricK8sJobPodFailed = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobPodFailed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sJobPodFailed, descrMetricK8sJobPodFailed,
                                         unitMetricK8sJobPodFailed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobPodFailed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sJobPodFailed, descrMetricK8sJobPodFailed,
                                          unitMetricK8sJobPodFailed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobPodFailed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobPodFailed, descrMetricK8sJobPodFailed, unitMetricK8sJobPodFailed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobPodFailed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobPodFailed, descrMetricK8sJobPodFailed, unitMetricK8sJobPodFailed);
}

/**
  The max desired number of pods the job should run at any given time.
  <p>
  This metric aligns with the @code parallelism @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobspec-v1-batch">K8s
  JobSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sJobPodMaxParallel = "k8s.job.pod.max_parallel";
static constexpr const char *descrMetricK8sJobPodMaxParallel =
    "The max desired number of pods the job should run at any given time.";
static constexpr const char *unitMetricK8sJobPodMaxParallel = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobPodMaxParallel(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(
      kMetricK8sJobPodMaxParallel, descrMetricK8sJobPodMaxParallel, unitMetricK8sJobPodMaxParallel);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobPodMaxParallel(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sJobPodMaxParallel, descrMetricK8sJobPodMaxParallel, unitMetricK8sJobPodMaxParallel);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobPodMaxParallel(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobPodMaxParallel, descrMetricK8sJobPodMaxParallel, unitMetricK8sJobPodMaxParallel);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobPodMaxParallel(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobPodMaxParallel, descrMetricK8sJobPodMaxParallel, unitMetricK8sJobPodMaxParallel);
}

/**
  The number of pods which reached phase Succeeded for a job.
  <p>
  This metric aligns with the @code succeeded @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sJobPodSuccessful = "k8s.job.pod.successful";
static constexpr const char *descrMetricK8sJobPodSuccessful =
    "The number of pods which reached phase Succeeded for a job.";
static constexpr const char *unitMetricK8sJobPodSuccessful = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobPodSuccessful(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sJobPodSuccessful, descrMetricK8sJobPodSuccessful,
                                         unitMetricK8sJobPodSuccessful);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobPodSuccessful(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sJobPodSuccessful, descrMetricK8sJobPodSuccessful, unitMetricK8sJobPodSuccessful);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobPodSuccessful(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobPodSuccessful, descrMetricK8sJobPodSuccessful, unitMetricK8sJobPodSuccessful);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobPodSuccessful(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobPodSuccessful, descrMetricK8sJobPodSuccessful, unitMetricK8sJobPodSuccessful);
}

/**
  Deprecated, use @code k8s.job.pod.successful @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.job.pod.successful @endcode.", "reason": "renamed", "renamed_to":
  "k8s.job.pod.successful"} <p> This metric aligns with the @code succeeded @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#jobstatus-v1-batch">K8s
  JobStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sJobSuccessfulPods =
    "k8s.job.successful_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sJobSuccessfulPods =
    "Deprecated, use `k8s.job.pod.successful` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sJobSuccessfulPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sJobSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(
      kMetricK8sJobSuccessfulPods, descrMetricK8sJobSuccessfulPods, unitMetricK8sJobSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sJobSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sJobSuccessfulPods, descrMetricK8sJobSuccessfulPods, unitMetricK8sJobSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sJobSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sJobSuccessfulPods, descrMetricK8sJobSuccessfulPods, unitMetricK8sJobSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sJobSuccessfulPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sJobSuccessfulPods, descrMetricK8sJobSuccessfulPods, unitMetricK8sJobSuccessfulPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Describes number of K8s namespaces that are currently in a given phase.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNamespacePhase = "k8s.namespace.phase";
static constexpr const char *descrMetricK8sNamespacePhase =
    "Describes number of K8s namespaces that are currently in a given phase.";
static constexpr const char *unitMetricK8sNamespacePhase = "{namespace}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNamespacePhase(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNamespacePhase, descrMetricK8sNamespacePhase,
                                         unitMetricK8sNamespacePhase);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNamespacePhase(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNamespacePhase, descrMetricK8sNamespacePhase,
                                          unitMetricK8sNamespacePhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNamespacePhase(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sNamespacePhase, descrMetricK8sNamespacePhase, unitMetricK8sNamespacePhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNamespacePhase(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sNamespacePhase, descrMetricK8sNamespacePhase, unitMetricK8sNamespacePhase);
}

/**
  Deprecated, use @code k8s.node.cpu.allocatable @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.node.cpu.allocatable @endcode.", "reason": "renamed",
  "renamed_to": "k8s.node.cpu.allocatable"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sNodeAllocatableCpu =
    "k8s.node.allocatable.cpu";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sNodeAllocatableCpu =
    "Deprecated, use `k8s.node.cpu.allocatable` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sNodeAllocatableCpu = "{cpu}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeAllocatableCpu(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeAllocatableCpu,
                                         descrMetricK8sNodeAllocatableCpu,
                                         unitMetricK8sNodeAllocatableCpu);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeAllocatableCpu(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeAllocatableCpu,
                                          descrMetricK8sNodeAllocatableCpu,
                                          unitMetricK8sNodeAllocatableCpu);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeAllocatableCpu(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeAllocatableCpu,
                                                   descrMetricK8sNodeAllocatableCpu,
                                                   unitMetricK8sNodeAllocatableCpu);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeAllocatableCpu(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeAllocatableCpu,
                                                    descrMetricK8sNodeAllocatableCpu,
                                                    unitMetricK8sNodeAllocatableCpu);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.node.ephemeral_storage.allocatable @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.node.ephemeral_storage.allocatable @endcode.", "reason":
  "renamed", "renamed_to": "k8s.node.ephemeral_storage.allocatable"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sNodeAllocatableEphemeralStorage =
    "k8s.node.allocatable.ephemeral_storage";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *descrMetricK8sNodeAllocatableEphemeralStorage =
        "Deprecated, use `k8s.node.ephemeral_storage.allocatable` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sNodeAllocatableEphemeralStorage =
    "By";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeAllocatableEphemeralStorage(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeAllocatableEphemeralStorage,
                                         descrMetricK8sNodeAllocatableEphemeralStorage,
                                         unitMetricK8sNodeAllocatableEphemeralStorage);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeAllocatableEphemeralStorage(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeAllocatableEphemeralStorage,
                                          descrMetricK8sNodeAllocatableEphemeralStorage,
                                          unitMetricK8sNodeAllocatableEphemeralStorage);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeAllocatableEphemeralStorage(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeAllocatableEphemeralStorage,
                                                   descrMetricK8sNodeAllocatableEphemeralStorage,
                                                   unitMetricK8sNodeAllocatableEphemeralStorage);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeAllocatableEphemeralStorage(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeAllocatableEphemeralStorage,
                                                    descrMetricK8sNodeAllocatableEphemeralStorage,
                                                    unitMetricK8sNodeAllocatableEphemeralStorage);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.node.memory.allocatable @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.node.memory.allocatable @endcode.", "reason": "renamed",
  "renamed_to": "k8s.node.memory.allocatable"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sNodeAllocatableMemory =
    "k8s.node.allocatable.memory";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sNodeAllocatableMemory =
    "Deprecated, use `k8s.node.memory.allocatable` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sNodeAllocatableMemory = "By";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeAllocatableMemory(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeAllocatableMemory,
                                         descrMetricK8sNodeAllocatableMemory,
                                         unitMetricK8sNodeAllocatableMemory);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeAllocatableMemory(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeAllocatableMemory,
                                          descrMetricK8sNodeAllocatableMemory,
                                          unitMetricK8sNodeAllocatableMemory);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeAllocatableMemory(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeAllocatableMemory,
                                                   descrMetricK8sNodeAllocatableMemory,
                                                   unitMetricK8sNodeAllocatableMemory);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeAllocatableMemory(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeAllocatableMemory,
                                                    descrMetricK8sNodeAllocatableMemory,
                                                    unitMetricK8sNodeAllocatableMemory);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.node.pod.allocatable @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.node.pod.allocatable @endcode.", "reason": "renamed",
  "renamed_to": "k8s.node.pod.allocatable"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sNodeAllocatablePods =
    "k8s.node.allocatable.pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sNodeAllocatablePods =
    "Deprecated, use `k8s.node.pod.allocatable` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sNodeAllocatablePods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeAllocatablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeAllocatablePods,
                                         descrMetricK8sNodeAllocatablePods,
                                         unitMetricK8sNodeAllocatablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeAllocatablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeAllocatablePods,
                                          descrMetricK8sNodeAllocatablePods,
                                          unitMetricK8sNodeAllocatablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeAllocatablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeAllocatablePods,
                                                   descrMetricK8sNodeAllocatablePods,
                                                   unitMetricK8sNodeAllocatablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeAllocatablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeAllocatablePods,
                                                    descrMetricK8sNodeAllocatablePods,
                                                    unitMetricK8sNodeAllocatablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Describes the condition of a particular Node.
  <p>
  All possible node condition pairs (type and status) will be reported at each time interval to
  avoid missing metrics. Condition pairs corresponding to the current conditions' statuses will be
  non-zero. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeConditionStatus = "k8s.node.condition.status";
static constexpr const char *descrMetricK8sNodeConditionStatus =
    "Describes the condition of a particular Node.";
static constexpr const char *unitMetricK8sNodeConditionStatus = "{node}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeConditionStatus(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeConditionStatus,
                                         descrMetricK8sNodeConditionStatus,
                                         unitMetricK8sNodeConditionStatus);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeConditionStatus(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeConditionStatus,
                                          descrMetricK8sNodeConditionStatus,
                                          unitMetricK8sNodeConditionStatus);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeConditionStatus(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeConditionStatus,
                                                   descrMetricK8sNodeConditionStatus,
                                                   unitMetricK8sNodeConditionStatus);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeConditionStatus(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeConditionStatus,
                                                    descrMetricK8sNodeConditionStatus,
                                                    unitMetricK8sNodeConditionStatus);
}

/**
  Amount of CPU allocatable on the node.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeCpuAllocatable = "k8s.node.cpu.allocatable";
static constexpr const char *descrMetricK8sNodeCpuAllocatable =
    "Amount of CPU allocatable on the node.";
static constexpr const char *unitMetricK8sNodeCpuAllocatable = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeCpuAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeCpuAllocatable,
                                         descrMetricK8sNodeCpuAllocatable,
                                         unitMetricK8sNodeCpuAllocatable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeCpuAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeCpuAllocatable,
                                          descrMetricK8sNodeCpuAllocatable,
                                          unitMetricK8sNodeCpuAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeCpuAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeCpuAllocatable,
                                                   descrMetricK8sNodeCpuAllocatable,
                                                   unitMetricK8sNodeCpuAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeCpuAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeCpuAllocatable,
                                                    descrMetricK8sNodeCpuAllocatable,
                                                    unitMetricK8sNodeCpuAllocatable);
}

/**
  Total CPU time consumed.
  <p>
  Total CPU time consumed by the specific Node on all available CPU cores
  <p>
  counter
 */
static constexpr const char *kMetricK8sNodeCpuTime     = "k8s.node.cpu.time";
static constexpr const char *descrMetricK8sNodeCpuTime = "Total CPU time consumed.";
static constexpr const char *unitMetricK8sNodeCpuTime  = "s";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>> CreateSyncInt64MetricK8sNodeCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sNodeCpuTime, descrMetricK8sNodeCpuTime,
                                    unitMetricK8sNodeCpuTime);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sNodeCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sNodeCpuTime, descrMetricK8sNodeCpuTime,
                                    unitMetricK8sNodeCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sNodeCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(kMetricK8sNodeCpuTime, descrMetricK8sNodeCpuTime,
                                             unitMetricK8sNodeCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeCpuTime(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(kMetricK8sNodeCpuTime, descrMetricK8sNodeCpuTime,
                                              unitMetricK8sNodeCpuTime);
}

/**
  Node's CPU usage, measured in CPUs. Range from 0 to the number of allocatable CPUs.
  <p>
  CPU usage of the specific Node on all available CPU cores. It is calculated as the change in
  cumulative CPU time (k8s.node.cpu.time) over a measurement interval, divided by the elapsed time:
  usageCores = (cpuTimeEnd - cpuTimeStart) / elapsedSeconds <p> gauge
 */
static constexpr const char *kMetricK8sNodeCpuUsage = "k8s.node.cpu.usage";
static constexpr const char *descrMetricK8sNodeCpuUsage =
    "Node's CPU usage, measured in CPUs. Range from 0 to the number of allocatable CPUs.";
static constexpr const char *unitMetricK8sNodeCpuUsage = "{cpu}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>> CreateSyncInt64MetricK8sNodeCpuUsage(
    metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sNodeCpuUsage, descrMetricK8sNodeCpuUsage,
                                 unitMetricK8sNodeCpuUsage);
}

static inline nostd::unique_ptr<metrics::Gauge<double>> CreateSyncDoubleMetricK8sNodeCpuUsage(
    metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sNodeCpuUsage, descrMetricK8sNodeCpuUsage,
                                  unitMetricK8sNodeCpuUsage);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeCpuUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sNodeCpuUsage, descrMetricK8sNodeCpuUsage,
                                           unitMetricK8sNodeCpuUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeCpuUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sNodeCpuUsage, descrMetricK8sNodeCpuUsage,
                                            unitMetricK8sNodeCpuUsage);
}

/**
  Amount of ephemeral-storage allocatable on the node.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeEphemeralStorageAllocatable =
    "k8s.node.ephemeral_storage.allocatable";
static constexpr const char *descrMetricK8sNodeEphemeralStorageAllocatable =
    "Amount of ephemeral-storage allocatable on the node.";
static constexpr const char *unitMetricK8sNodeEphemeralStorageAllocatable = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeEphemeralStorageAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeEphemeralStorageAllocatable,
                                         descrMetricK8sNodeEphemeralStorageAllocatable,
                                         unitMetricK8sNodeEphemeralStorageAllocatable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeEphemeralStorageAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeEphemeralStorageAllocatable,
                                          descrMetricK8sNodeEphemeralStorageAllocatable,
                                          unitMetricK8sNodeEphemeralStorageAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeEphemeralStorageAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeEphemeralStorageAllocatable,
                                                   descrMetricK8sNodeEphemeralStorageAllocatable,
                                                   unitMetricK8sNodeEphemeralStorageAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeEphemeralStorageAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeEphemeralStorageAllocatable,
                                                    descrMetricK8sNodeEphemeralStorageAllocatable,
                                                    unitMetricK8sNodeEphemeralStorageAllocatable);
}

/**
  Node filesystem available bytes.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.AvailableBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Fs</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeFilesystemAvailable = "k8s.node.filesystem.available";
static constexpr const char *descrMetricK8sNodeFilesystemAvailable =
    "Node filesystem available bytes.";
static constexpr const char *unitMetricK8sNodeFilesystemAvailable = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeFilesystemAvailable,
                                         descrMetricK8sNodeFilesystemAvailable,
                                         unitMetricK8sNodeFilesystemAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeFilesystemAvailable,
                                          descrMetricK8sNodeFilesystemAvailable,
                                          unitMetricK8sNodeFilesystemAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeFilesystemAvailable,
                                                   descrMetricK8sNodeFilesystemAvailable,
                                                   unitMetricK8sNodeFilesystemAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeFilesystemAvailable,
                                                    descrMetricK8sNodeFilesystemAvailable,
                                                    unitMetricK8sNodeFilesystemAvailable);
}

/**
  Node filesystem capacity.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.CapacityBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Fs</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeFilesystemCapacity     = "k8s.node.filesystem.capacity";
static constexpr const char *descrMetricK8sNodeFilesystemCapacity = "Node filesystem capacity.";
static constexpr const char *unitMetricK8sNodeFilesystemCapacity  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeFilesystemCapacity,
                                         descrMetricK8sNodeFilesystemCapacity,
                                         unitMetricK8sNodeFilesystemCapacity);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeFilesystemCapacity,
                                          descrMetricK8sNodeFilesystemCapacity,
                                          unitMetricK8sNodeFilesystemCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeFilesystemCapacity,
                                                   descrMetricK8sNodeFilesystemCapacity,
                                                   unitMetricK8sNodeFilesystemCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeFilesystemCapacity,
                                                    descrMetricK8sNodeFilesystemCapacity,
                                                    unitMetricK8sNodeFilesystemCapacity);
}

/**
  The total inodes in the node's root filesystem.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.Inodes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Fs</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeFilesystemInodeCount = "k8s.node.filesystem.inode.count";
static constexpr const char *descrMetricK8sNodeFilesystemInodeCount =
    "The total inodes in the node's root filesystem.";
static constexpr const char *unitMetricK8sNodeFilesystemInodeCount = "{inode}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeFilesystemInodeCount(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeFilesystemInodeCount,
                                         descrMetricK8sNodeFilesystemInodeCount,
                                         unitMetricK8sNodeFilesystemInodeCount);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeFilesystemInodeCount(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeFilesystemInodeCount,
                                          descrMetricK8sNodeFilesystemInodeCount,
                                          unitMetricK8sNodeFilesystemInodeCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeFilesystemInodeCount(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeFilesystemInodeCount,
                                                   descrMetricK8sNodeFilesystemInodeCount,
                                                   unitMetricK8sNodeFilesystemInodeCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeFilesystemInodeCount(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeFilesystemInodeCount,
                                                    descrMetricK8sNodeFilesystemInodeCount,
                                                    unitMetricK8sNodeFilesystemInodeCount);
}

/**
  The free inodes in the node's root filesystem.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.InodesFree</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Fs</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeFilesystemInodeFree = "k8s.node.filesystem.inode.free";
static constexpr const char *descrMetricK8sNodeFilesystemInodeFree =
    "The free inodes in the node's root filesystem.";
static constexpr const char *unitMetricK8sNodeFilesystemInodeFree = "{inode}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeFilesystemInodeFree(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeFilesystemInodeFree,
                                         descrMetricK8sNodeFilesystemInodeFree,
                                         unitMetricK8sNodeFilesystemInodeFree);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeFilesystemInodeFree(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeFilesystemInodeFree,
                                          descrMetricK8sNodeFilesystemInodeFree,
                                          unitMetricK8sNodeFilesystemInodeFree);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeFilesystemInodeFree(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeFilesystemInodeFree,
                                                   descrMetricK8sNodeFilesystemInodeFree,
                                                   unitMetricK8sNodeFilesystemInodeFree);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeFilesystemInodeFree(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeFilesystemInodeFree,
                                                    descrMetricK8sNodeFilesystemInodeFree,
                                                    unitMetricK8sNodeFilesystemInodeFree);
}

/**
  Node filesystem usage.
  <p>
  This may not equal capacity - available.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.UsedBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Fs</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeFilesystemUsage     = "k8s.node.filesystem.usage";
static constexpr const char *descrMetricK8sNodeFilesystemUsage = "Node filesystem usage.";
static constexpr const char *unitMetricK8sNodeFilesystemUsage  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeFilesystemUsage,
                                         descrMetricK8sNodeFilesystemUsage,
                                         unitMetricK8sNodeFilesystemUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeFilesystemUsage,
                                          descrMetricK8sNodeFilesystemUsage,
                                          unitMetricK8sNodeFilesystemUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeFilesystemUsage,
                                                   descrMetricK8sNodeFilesystemUsage,
                                                   unitMetricK8sNodeFilesystemUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeFilesystemUsage,
                                                    descrMetricK8sNodeFilesystemUsage,
                                                    unitMetricK8sNodeFilesystemUsage);
}

/**
  Amount of memory allocatable on the node.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodeMemoryAllocatable = "k8s.node.memory.allocatable";
static constexpr const char *descrMetricK8sNodeMemoryAllocatable =
    "Amount of memory allocatable on the node.";
static constexpr const char *unitMetricK8sNodeMemoryAllocatable = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeMemoryAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeMemoryAllocatable,
                                         descrMetricK8sNodeMemoryAllocatable,
                                         unitMetricK8sNodeMemoryAllocatable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeMemoryAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeMemoryAllocatable,
                                          descrMetricK8sNodeMemoryAllocatable,
                                          unitMetricK8sNodeMemoryAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeMemoryAllocatable,
                                                   descrMetricK8sNodeMemoryAllocatable,
                                                   unitMetricK8sNodeMemoryAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeMemoryAllocatable,
                                                    descrMetricK8sNodeMemoryAllocatable,
                                                    unitMetricK8sNodeMemoryAllocatable);
}

/**
  Node memory available.
  <p>
  Available memory for use.  This is defined as the memory limit - workingSetBytes. If memory limit
  is undefined, the available bytes is omitted. This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.AvailableBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeMemoryAvailable     = "k8s.node.memory.available";
static constexpr const char *descrMetricK8sNodeMemoryAvailable = "Node memory available.";
static constexpr const char *unitMetricK8sNodeMemoryAvailable  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeMemoryAvailable,
                                         descrMetricK8sNodeMemoryAvailable,
                                         unitMetricK8sNodeMemoryAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeMemoryAvailable,
                                          descrMetricK8sNodeMemoryAvailable,
                                          unitMetricK8sNodeMemoryAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeMemoryAvailable,
                                                   descrMetricK8sNodeMemoryAvailable,
                                                   unitMetricK8sNodeMemoryAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeMemoryAvailable,
                                                    descrMetricK8sNodeMemoryAvailable,
                                                    unitMetricK8sNodeMemoryAvailable);
}

/**
  Deprecated, use @code k8s.node.paging.faults @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.node.paging.faults @endcode.", "reason": "renamed", "renamed_to":
  "k8s.node.paging.faults"} <p> Cumulative number of major/minor page faults. This metric is derived
  from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.PageFaults</a>
  and <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.MajorPageFaults</a>
  fields of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> counter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sNodeMemoryPagingFaults =
    "k8s.node.memory.paging.faults";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sNodeMemoryPagingFaults =
    "Deprecated, use `k8s.node.paging.faults` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sNodeMemoryPagingFaults =
    "{fault}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sNodeMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateUInt64Counter(kMetricK8sNodeMemoryPagingFaults,
                                    descrMetricK8sNodeMemoryPagingFaults,
                                    unitMetricK8sNodeMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::Counter<double>>
CreateSyncDoubleMetricK8sNodeMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleCounter(kMetricK8sNodeMemoryPagingFaults,
                                    descrMetricK8sNodeMemoryPagingFaults,
                                    unitMetricK8sNodeMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableCounter(kMetricK8sNodeMemoryPagingFaults,
                                             descrMetricK8sNodeMemoryPagingFaults,
                                             unitMetricK8sNodeMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableCounter(kMetricK8sNodeMemoryPagingFaults,
                                              descrMetricK8sNodeMemoryPagingFaults,
                                              unitMetricK8sNodeMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Node memory RSS.
  <p>
  The amount of anonymous and swap cache memory (includes transparent hugepages).
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.RSSBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeMemoryRss     = "k8s.node.memory.rss";
static constexpr const char *descrMetricK8sNodeMemoryRss = "Node memory RSS.";
static constexpr const char *unitMetricK8sNodeMemoryRss  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeMemoryRss(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeMemoryRss, descrMetricK8sNodeMemoryRss,
                                         unitMetricK8sNodeMemoryRss);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeMemoryRss(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeMemoryRss, descrMetricK8sNodeMemoryRss,
                                          unitMetricK8sNodeMemoryRss);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryRss(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sNodeMemoryRss, descrMetricK8sNodeMemoryRss, unitMetricK8sNodeMemoryRss);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryRss(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sNodeMemoryRss, descrMetricK8sNodeMemoryRss, unitMetricK8sNodeMemoryRss);
}

/**
  Memory usage of the Node.
  <p>
  Total memory in use. This includes all memory regardless of when it was accessed.
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.UsageBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeMemoryUsage     = "k8s.node.memory.usage";
static constexpr const char *descrMetricK8sNodeMemoryUsage = "Memory usage of the Node.";
static constexpr const char *unitMetricK8sNodeMemoryUsage  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeMemoryUsage, descrMetricK8sNodeMemoryUsage,
                                         unitMetricK8sNodeMemoryUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeMemoryUsage, descrMetricK8sNodeMemoryUsage,
                                          unitMetricK8sNodeMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sNodeMemoryUsage, descrMetricK8sNodeMemoryUsage, unitMetricK8sNodeMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sNodeMemoryUsage, descrMetricK8sNodeMemoryUsage, unitMetricK8sNodeMemoryUsage);
}

/**
  Node memory working set.
  <p>
  The amount of working set memory. This includes recently accessed memory, dirty memory, and kernel
  memory. WorkingSetBytes is <= UsageBytes. This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.WorkingSetBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeMemoryWorkingSet     = "k8s.node.memory.working_set";
static constexpr const char *descrMetricK8sNodeMemoryWorkingSet = "Node memory working set.";
static constexpr const char *unitMetricK8sNodeMemoryWorkingSet  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeMemoryWorkingSet,
                                         descrMetricK8sNodeMemoryWorkingSet,
                                         unitMetricK8sNodeMemoryWorkingSet);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeMemoryWorkingSet,
                                          descrMetricK8sNodeMemoryWorkingSet,
                                          unitMetricK8sNodeMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeMemoryWorkingSet,
                                                   descrMetricK8sNodeMemoryWorkingSet,
                                                   unitMetricK8sNodeMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeMemoryWorkingSet,
                                                    descrMetricK8sNodeMemoryWorkingSet,
                                                    unitMetricK8sNodeMemoryWorkingSet);
}

/**
  Node network errors.
  <p>
  counter
 */
static constexpr const char *kMetricK8sNodeNetworkErrors     = "k8s.node.network.errors";
static constexpr const char *descrMetricK8sNodeNetworkErrors = "Node network errors.";
static constexpr const char *unitMetricK8sNodeNetworkErrors  = "{error}";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sNodeNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sNodeNetworkErrors, descrMetricK8sNodeNetworkErrors,
                                    unitMetricK8sNodeNetworkErrors);
}

static inline nostd::unique_ptr<metrics::Counter<double>>
CreateSyncDoubleMetricK8sNodeNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sNodeNetworkErrors, descrMetricK8sNodeNetworkErrors,
                                    unitMetricK8sNodeNetworkErrors);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(
      kMetricK8sNodeNetworkErrors, descrMetricK8sNodeNetworkErrors, unitMetricK8sNodeNetworkErrors);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(
      kMetricK8sNodeNetworkErrors, descrMetricK8sNodeNetworkErrors, unitMetricK8sNodeNetworkErrors);
}

/**
  Network bytes for the Node.
  <p>
  counter
 */
static constexpr const char *kMetricK8sNodeNetworkIo     = "k8s.node.network.io";
static constexpr const char *descrMetricK8sNodeNetworkIo = "Network bytes for the Node.";
static constexpr const char *unitMetricK8sNodeNetworkIo  = "By";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>> CreateSyncInt64MetricK8sNodeNetworkIo(
    metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sNodeNetworkIo, descrMetricK8sNodeNetworkIo,
                                    unitMetricK8sNodeNetworkIo);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sNodeNetworkIo(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sNodeNetworkIo, descrMetricK8sNodeNetworkIo,
                                    unitMetricK8sNodeNetworkIo);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeNetworkIo(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(kMetricK8sNodeNetworkIo, descrMetricK8sNodeNetworkIo,
                                             unitMetricK8sNodeNetworkIo);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeNetworkIo(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(kMetricK8sNodeNetworkIo, descrMetricK8sNodeNetworkIo,
                                              unitMetricK8sNodeNetworkIo);
}

/**
  Node memory paging faults.
  <p>
  Cumulative number of major/minor page faults.
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.PageFaults</a>
  and <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.MajorPageFaults</a>
  fields of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#NodeStats">NodeStats.Memory</a>
  of the Kubelet's stats API. <p> counter
 */
static constexpr const char *kMetricK8sNodePagingFaults     = "k8s.node.paging.faults";
static constexpr const char *descrMetricK8sNodePagingFaults = "Node memory paging faults.";
static constexpr const char *unitMetricK8sNodePagingFaults  = "{fault}";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sNodePagingFaults(metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sNodePagingFaults, descrMetricK8sNodePagingFaults,
                                    unitMetricK8sNodePagingFaults);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sNodePagingFaults(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sNodePagingFaults, descrMetricK8sNodePagingFaults,
                                    unitMetricK8sNodePagingFaults);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodePagingFaults(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(
      kMetricK8sNodePagingFaults, descrMetricK8sNodePagingFaults, unitMetricK8sNodePagingFaults);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodePagingFaults(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(
      kMetricK8sNodePagingFaults, descrMetricK8sNodePagingFaults, unitMetricK8sNodePagingFaults);
}

/**
  Amount of pods allocatable on the node.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sNodePodAllocatable = "k8s.node.pod.allocatable";
static constexpr const char *descrMetricK8sNodePodAllocatable =
    "Amount of pods allocatable on the node.";
static constexpr const char *unitMetricK8sNodePodAllocatable = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodePodAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodePodAllocatable,
                                         descrMetricK8sNodePodAllocatable,
                                         unitMetricK8sNodePodAllocatable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodePodAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodePodAllocatable,
                                          descrMetricK8sNodePodAllocatable,
                                          unitMetricK8sNodePodAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodePodAllocatable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodePodAllocatable,
                                                   descrMetricK8sNodePodAllocatable,
                                                   unitMetricK8sNodePodAllocatable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodePodAllocatable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodePodAllocatable,
                                                    descrMetricK8sNodePodAllocatable,
                                                    unitMetricK8sNodePodAllocatable);
}

/**
  Node's system container CPU time.
  <p>
  This metric is derived from the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L236">CPUStats.UsageCoreNanoSeconds</a>
  field of the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L157C6-L157C20">ContainerStats</a>
  of <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L40">Node.SystemContainers</a>
  of the Kubelet's stats API. <p> counter
 */
static constexpr const char *kMetricK8sNodeSystemContainerCpuTime =
    "k8s.node.system_container.cpu.time";
static constexpr const char *descrMetricK8sNodeSystemContainerCpuTime =
    "Node's system container CPU time.";
static constexpr const char *unitMetricK8sNodeSystemContainerCpuTime = "s";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sNodeSystemContainerCpuTime(metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sNodeSystemContainerCpuTime,
                                    descrMetricK8sNodeSystemContainerCpuTime,
                                    unitMetricK8sNodeSystemContainerCpuTime);
}

static inline nostd::unique_ptr<metrics::Counter<double>>
CreateSyncDoubleMetricK8sNodeSystemContainerCpuTime(metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sNodeSystemContainerCpuTime,
                                    descrMetricK8sNodeSystemContainerCpuTime,
                                    unitMetricK8sNodeSystemContainerCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeSystemContainerCpuTime(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(kMetricK8sNodeSystemContainerCpuTime,
                                             descrMetricK8sNodeSystemContainerCpuTime,
                                             unitMetricK8sNodeSystemContainerCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeSystemContainerCpuTime(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(kMetricK8sNodeSystemContainerCpuTime,
                                              descrMetricK8sNodeSystemContainerCpuTime,
                                              unitMetricK8sNodeSystemContainerCpuTime);
}

/**
  Node's system container CPU usage, measured in CPUs.
  <p>
  CPU usage of the specific System Container on all available CPU cores. It is calculated as the
  change in cumulative CPU time (k8s.node.system_container.cpu.time) over a measurement interval,
  divided by the elapsed time: usageCores = (cpuTimeEnd - cpuTimeStart) / elapsedSeconds <p> gauge
 */
static constexpr const char *kMetricK8sNodeSystemContainerCpuUsage =
    "k8s.node.system_container.cpu.usage";
static constexpr const char *descrMetricK8sNodeSystemContainerCpuUsage =
    "Node's system container CPU usage, measured in CPUs.";
static constexpr const char *unitMetricK8sNodeSystemContainerCpuUsage = "{cpu}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sNodeSystemContainerCpuUsage(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sNodeSystemContainerCpuUsage,
                                 descrMetricK8sNodeSystemContainerCpuUsage,
                                 unitMetricK8sNodeSystemContainerCpuUsage);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sNodeSystemContainerCpuUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sNodeSystemContainerCpuUsage,
                                  descrMetricK8sNodeSystemContainerCpuUsage,
                                  unitMetricK8sNodeSystemContainerCpuUsage);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeSystemContainerCpuUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sNodeSystemContainerCpuUsage,
                                           descrMetricK8sNodeSystemContainerCpuUsage,
                                           unitMetricK8sNodeSystemContainerCpuUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeSystemContainerCpuUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sNodeSystemContainerCpuUsage,
                                            descrMetricK8sNodeSystemContainerCpuUsage,
                                            unitMetricK8sNodeSystemContainerCpuUsage);
}

/**
  Node's system container memory usage.
  <p>
  This metric is derived from the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L252">MemoryStats.UsageBytes</a>
  field of the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L157C6-L157C20">ContainerStats</a>
  of <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L40">Node.SystemContainers</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeSystemContainerMemoryUsage =
    "k8s.node.system_container.memory.usage";
static constexpr const char *descrMetricK8sNodeSystemContainerMemoryUsage =
    "Node's system container memory usage.";
static constexpr const char *unitMetricK8sNodeSystemContainerMemoryUsage = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeSystemContainerMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeSystemContainerMemoryUsage,
                                         descrMetricK8sNodeSystemContainerMemoryUsage,
                                         unitMetricK8sNodeSystemContainerMemoryUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeSystemContainerMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeSystemContainerMemoryUsage,
                                          descrMetricK8sNodeSystemContainerMemoryUsage,
                                          unitMetricK8sNodeSystemContainerMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeSystemContainerMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sNodeSystemContainerMemoryUsage,
                                                   descrMetricK8sNodeSystemContainerMemoryUsage,
                                                   unitMetricK8sNodeSystemContainerMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeSystemContainerMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sNodeSystemContainerMemoryUsage,
                                                    descrMetricK8sNodeSystemContainerMemoryUsage,
                                                    unitMetricK8sNodeSystemContainerMemoryUsage);
}

/**
  The amount of working set memory.
  <p>
  This metric is derived from the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L256">MemoryStats.WorkingSetBytes</a>
  field of the <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L157C6-L157C20">ContainerStats</a>
  of <a
  href="https://github.com/kubernetes/kubelet/blob/v0.35.2/pkg/apis/stats/v1alpha1/types.go#L40">Node.SystemContainers</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sNodeSystemContainerMemoryWorkingSet =
    "k8s.node.system_container.memory.working_set";
static constexpr const char *descrMetricK8sNodeSystemContainerMemoryWorkingSet =
    "The amount of working set memory.";
static constexpr const char *unitMetricK8sNodeSystemContainerMemoryWorkingSet = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sNodeSystemContainerMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sNodeSystemContainerMemoryWorkingSet,
                                         descrMetricK8sNodeSystemContainerMemoryWorkingSet,
                                         unitMetricK8sNodeSystemContainerMemoryWorkingSet);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sNodeSystemContainerMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sNodeSystemContainerMemoryWorkingSet,
                                          descrMetricK8sNodeSystemContainerMemoryWorkingSet,
                                          unitMetricK8sNodeSystemContainerMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sNodeSystemContainerMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sNodeSystemContainerMemoryWorkingSet,
      descrMetricK8sNodeSystemContainerMemoryWorkingSet,
      unitMetricK8sNodeSystemContainerMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sNodeSystemContainerMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sNodeSystemContainerMemoryWorkingSet,
      descrMetricK8sNodeSystemContainerMemoryWorkingSet,
      unitMetricK8sNodeSystemContainerMemoryWorkingSet);
}

/**
  The time the Node has been running.
  <p>
  Instrumentations SHOULD use a gauge with type @code double @endcode and measure uptime in seconds
  as a floating point number with the highest precision available. The actual accuracy would depend
  on the instrumentation and operating system. <p> gauge
 */
static constexpr const char *kMetricK8sNodeUptime     = "k8s.node.uptime";
static constexpr const char *descrMetricK8sNodeUptime = "The time the Node has been running.";
static constexpr const char *unitMetricK8sNodeUptime  = "s";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>> CreateSyncInt64MetricK8sNodeUptime(
    metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sNodeUptime, descrMetricK8sNodeUptime,
                                 unitMetricK8sNodeUptime);
}

static inline nostd::unique_ptr<metrics::Gauge<double>> CreateSyncDoubleMetricK8sNodeUptime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sNodeUptime, descrMetricK8sNodeUptime,
                                  unitMetricK8sNodeUptime);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sNodeUptime(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sNodeUptime, descrMetricK8sNodeUptime,
                                           unitMetricK8sNodeUptime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncDoubleMetricK8sNodeUptime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sNodeUptime, descrMetricK8sNodeUptime,
                                            unitMetricK8sNodeUptime);
}

/**
  Number of PersistentVolumes in a given phase.
  <p>
  All possible phases should be reported at each interval to avoid gaps in the time series.
  This metric is derived from the @code .status.phase @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/persistent-volume-v1/#PersistentVolumeStatus">K8s
  PersistentVolumeStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sPersistentvolumeStatusPhase =
    "k8s.persistentvolume.status.phase";
static constexpr const char *descrMetricK8sPersistentvolumeStatusPhase =
    "Number of PersistentVolumes in a given phase.";
static constexpr const char *unitMetricK8sPersistentvolumeStatusPhase = "{persistentvolume}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPersistentvolumeStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPersistentvolumeStatusPhase,
                                         descrMetricK8sPersistentvolumeStatusPhase,
                                         unitMetricK8sPersistentvolumeStatusPhase);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPersistentvolumeStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPersistentvolumeStatusPhase,
                                          descrMetricK8sPersistentvolumeStatusPhase,
                                          unitMetricK8sPersistentvolumeStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPersistentvolumeStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPersistentvolumeStatusPhase,
                                                   descrMetricK8sPersistentvolumeStatusPhase,
                                                   unitMetricK8sPersistentvolumeStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPersistentvolumeStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPersistentvolumeStatusPhase,
                                                    descrMetricK8sPersistentvolumeStatusPhase,
                                                    unitMetricK8sPersistentvolumeStatusPhase);
}

/**
  The storage capacity of the PersistentVolume.
  <p>
  This metric is derived from the @code .spec.capacity.storage @endcode field of the <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/persistent-volume-v1/#PersistentVolumeSpec">K8s
  PersistentVolumeSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sPersistentvolumeStorageCapacity =
    "k8s.persistentvolume.storage.capacity";
static constexpr const char *descrMetricK8sPersistentvolumeStorageCapacity =
    "The storage capacity of the PersistentVolume.";
static constexpr const char *unitMetricK8sPersistentvolumeStorageCapacity = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPersistentvolumeStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPersistentvolumeStorageCapacity,
                                         descrMetricK8sPersistentvolumeStorageCapacity,
                                         unitMetricK8sPersistentvolumeStorageCapacity);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPersistentvolumeStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPersistentvolumeStorageCapacity,
                                          descrMetricK8sPersistentvolumeStorageCapacity,
                                          unitMetricK8sPersistentvolumeStorageCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPersistentvolumeStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPersistentvolumeStorageCapacity,
                                                   descrMetricK8sPersistentvolumeStorageCapacity,
                                                   unitMetricK8sPersistentvolumeStorageCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPersistentvolumeStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPersistentvolumeStorageCapacity,
                                                    descrMetricK8sPersistentvolumeStorageCapacity,
                                                    unitMetricK8sPersistentvolumeStorageCapacity);
}

/**
  Number of PersistentVolumeClaims in a given phase.
  <p>
  All possible phases should be reported at each interval to avoid gaps in the time series.
  This metric is derived from the @code .status.phase @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/persistent-volume-claim-v1/#PersistentVolumeClaimStatus">K8s
  PersistentVolumeClaimStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sPersistentvolumeclaimStatusPhase =
    "k8s.persistentvolumeclaim.status.phase";
static constexpr const char *descrMetricK8sPersistentvolumeclaimStatusPhase =
    "Number of PersistentVolumeClaims in a given phase.";
static constexpr const char *unitMetricK8sPersistentvolumeclaimStatusPhase =
    "{persistentvolumeclaim}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPersistentvolumeclaimStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPersistentvolumeclaimStatusPhase,
                                         descrMetricK8sPersistentvolumeclaimStatusPhase,
                                         unitMetricK8sPersistentvolumeclaimStatusPhase);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPersistentvolumeclaimStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPersistentvolumeclaimStatusPhase,
                                          descrMetricK8sPersistentvolumeclaimStatusPhase,
                                          unitMetricK8sPersistentvolumeclaimStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPersistentvolumeclaimStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPersistentvolumeclaimStatusPhase,
                                                   descrMetricK8sPersistentvolumeclaimStatusPhase,
                                                   unitMetricK8sPersistentvolumeclaimStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPersistentvolumeclaimStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPersistentvolumeclaimStatusPhase,
                                                    descrMetricK8sPersistentvolumeclaimStatusPhase,
                                                    unitMetricK8sPersistentvolumeclaimStatusPhase);
}

/**
  The actual storage capacity provisioned for the PersistentVolumeClaim.
  <p>
  Only available when the PVC is bound. May differ from the requested capacity due to provisioner
  rounding. This metric is derived from the @code .status.capacity.storage @endcode field of the <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/persistent-volume-claim-v1/#PersistentVolumeClaimStatus">K8s
  PersistentVolumeClaimStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sPersistentvolumeclaimStorageCapacity =
    "k8s.persistentvolumeclaim.storage.capacity";
static constexpr const char *descrMetricK8sPersistentvolumeclaimStorageCapacity =
    "The actual storage capacity provisioned for the PersistentVolumeClaim.";
static constexpr const char *unitMetricK8sPersistentvolumeclaimStorageCapacity = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPersistentvolumeclaimStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPersistentvolumeclaimStorageCapacity,
                                         descrMetricK8sPersistentvolumeclaimStorageCapacity,
                                         unitMetricK8sPersistentvolumeclaimStorageCapacity);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPersistentvolumeclaimStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPersistentvolumeclaimStorageCapacity,
                                          descrMetricK8sPersistentvolumeclaimStorageCapacity,
                                          unitMetricK8sPersistentvolumeclaimStorageCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPersistentvolumeclaimStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPersistentvolumeclaimStorageCapacity,
      descrMetricK8sPersistentvolumeclaimStorageCapacity,
      unitMetricK8sPersistentvolumeclaimStorageCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPersistentvolumeclaimStorageCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPersistentvolumeclaimStorageCapacity,
      descrMetricK8sPersistentvolumeclaimStorageCapacity,
      unitMetricK8sPersistentvolumeclaimStorageCapacity);
}

/**
  The storage requested by the PersistentVolumeClaim.
  <p>
  This metric is derived from the @code .spec.resources.requests.storage @endcode field of the <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/config-and-storage-resources/persistent-volume-claim-v1/#PersistentVolumeClaimSpec">K8s
  PersistentVolumeClaimSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sPersistentvolumeclaimStorageRequest =
    "k8s.persistentvolumeclaim.storage.request";
static constexpr const char *descrMetricK8sPersistentvolumeclaimStorageRequest =
    "The storage requested by the PersistentVolumeClaim.";
static constexpr const char *unitMetricK8sPersistentvolumeclaimStorageRequest = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPersistentvolumeclaimStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPersistentvolumeclaimStorageRequest,
                                         descrMetricK8sPersistentvolumeclaimStorageRequest,
                                         unitMetricK8sPersistentvolumeclaimStorageRequest);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPersistentvolumeclaimStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPersistentvolumeclaimStorageRequest,
                                          descrMetricK8sPersistentvolumeclaimStorageRequest,
                                          unitMetricK8sPersistentvolumeclaimStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPersistentvolumeclaimStorageRequest(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPersistentvolumeclaimStorageRequest,
      descrMetricK8sPersistentvolumeclaimStorageRequest,
      unitMetricK8sPersistentvolumeclaimStorageRequest);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPersistentvolumeclaimStorageRequest(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPersistentvolumeclaimStorageRequest,
      descrMetricK8sPersistentvolumeclaimStorageRequest,
      unitMetricK8sPersistentvolumeclaimStorageRequest);
}

/**
  Total CPU time consumed.
  <p>
  Total CPU time consumed by the specific Pod on all available CPU cores
  <p>
  counter
 */
static constexpr const char *kMetricK8sPodCpuTime     = "k8s.pod.cpu.time";
static constexpr const char *descrMetricK8sPodCpuTime = "Total CPU time consumed.";
static constexpr const char *unitMetricK8sPodCpuTime  = "s";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>> CreateSyncInt64MetricK8sPodCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sPodCpuTime, descrMetricK8sPodCpuTime,
                                    unitMetricK8sPodCpuTime);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sPodCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sPodCpuTime, descrMetricK8sPodCpuTime,
                                    unitMetricK8sPodCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sPodCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(kMetricK8sPodCpuTime, descrMetricK8sPodCpuTime,
                                             unitMetricK8sPodCpuTime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncDoubleMetricK8sPodCpuTime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(kMetricK8sPodCpuTime, descrMetricK8sPodCpuTime,
                                              unitMetricK8sPodCpuTime);
}

/**
  Pod's CPU usage, measured in CPUs. Range from 0 to the number of allocatable CPUs.
  <p>
  CPU usage of the specific Pod on all available CPU cores. It is calculated as the change in
  cumulative CPU time (k8s.pod.cpu.time) over a measurement interval, divided by the elapsed time:
  usageCores = (cpuTimeEnd - cpuTimeStart) / elapsedSeconds <p> gauge
 */
static constexpr const char *kMetricK8sPodCpuUsage = "k8s.pod.cpu.usage";
static constexpr const char *descrMetricK8sPodCpuUsage =
    "Pod's CPU usage, measured in CPUs. Range from 0 to the number of allocatable CPUs.";
static constexpr const char *unitMetricK8sPodCpuUsage = "{cpu}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>> CreateSyncInt64MetricK8sPodCpuUsage(
    metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sPodCpuUsage, descrMetricK8sPodCpuUsage,
                                 unitMetricK8sPodCpuUsage);
}

static inline nostd::unique_ptr<metrics::Gauge<double>> CreateSyncDoubleMetricK8sPodCpuUsage(
    metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sPodCpuUsage, descrMetricK8sPodCpuUsage,
                                  unitMetricK8sPodCpuUsage);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sPodCpuUsage(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sPodCpuUsage, descrMetricK8sPodCpuUsage,
                                           unitMetricK8sPodCpuUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodCpuUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sPodCpuUsage, descrMetricK8sPodCpuUsage,
                                            unitMetricK8sPodCpuUsage);
}

/**
  Pod filesystem available bytes.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.AvailableBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.EphemeralStorage</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sPodFilesystemAvailable = "k8s.pod.filesystem.available";
static constexpr const char *descrMetricK8sPodFilesystemAvailable =
    "Pod filesystem available bytes.";
static constexpr const char *unitMetricK8sPodFilesystemAvailable = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodFilesystemAvailable,
                                         descrMetricK8sPodFilesystemAvailable,
                                         unitMetricK8sPodFilesystemAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodFilesystemAvailable,
                                          descrMetricK8sPodFilesystemAvailable,
                                          unitMetricK8sPodFilesystemAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodFilesystemAvailable,
                                                   descrMetricK8sPodFilesystemAvailable,
                                                   unitMetricK8sPodFilesystemAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodFilesystemAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodFilesystemAvailable,
                                                    descrMetricK8sPodFilesystemAvailable,
                                                    unitMetricK8sPodFilesystemAvailable);
}

/**
  Pod filesystem capacity.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.CapacityBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.EphemeralStorage</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sPodFilesystemCapacity     = "k8s.pod.filesystem.capacity";
static constexpr const char *descrMetricK8sPodFilesystemCapacity = "Pod filesystem capacity.";
static constexpr const char *unitMetricK8sPodFilesystemCapacity  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodFilesystemCapacity,
                                         descrMetricK8sPodFilesystemCapacity,
                                         unitMetricK8sPodFilesystemCapacity);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodFilesystemCapacity,
                                          descrMetricK8sPodFilesystemCapacity,
                                          unitMetricK8sPodFilesystemCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodFilesystemCapacity,
                                                   descrMetricK8sPodFilesystemCapacity,
                                                   unitMetricK8sPodFilesystemCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodFilesystemCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodFilesystemCapacity,
                                                    descrMetricK8sPodFilesystemCapacity,
                                                    unitMetricK8sPodFilesystemCapacity);
}

/**
  Pod filesystem usage.
  <p>
  This may not equal capacity - available.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#FsStats">FsStats.UsedBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.EphemeralStorage</a>
  of the Kubelet's stats API.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sPodFilesystemUsage     = "k8s.pod.filesystem.usage";
static constexpr const char *descrMetricK8sPodFilesystemUsage = "Pod filesystem usage.";
static constexpr const char *unitMetricK8sPodFilesystemUsage  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodFilesystemUsage,
                                         descrMetricK8sPodFilesystemUsage,
                                         unitMetricK8sPodFilesystemUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodFilesystemUsage,
                                          descrMetricK8sPodFilesystemUsage,
                                          unitMetricK8sPodFilesystemUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodFilesystemUsage,
                                                   descrMetricK8sPodFilesystemUsage,
                                                   unitMetricK8sPodFilesystemUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodFilesystemUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodFilesystemUsage,
                                                    descrMetricK8sPodFilesystemUsage,
                                                    unitMetricK8sPodFilesystemUsage);
}

/**
  Pod memory available.
  <p>
  Available memory for use.  This is defined as the memory limit - workingSetBytes. If memory limit
  is undefined, the available bytes is omitted. This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.AvailableBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodMemoryAvailable     = "k8s.pod.memory.available";
static constexpr const char *descrMetricK8sPodMemoryAvailable = "Pod memory available.";
static constexpr const char *unitMetricK8sPodMemoryAvailable  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodMemoryAvailable,
                                         descrMetricK8sPodMemoryAvailable,
                                         unitMetricK8sPodMemoryAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodMemoryAvailable,
                                          descrMetricK8sPodMemoryAvailable,
                                          unitMetricK8sPodMemoryAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodMemoryAvailable,
                                                   descrMetricK8sPodMemoryAvailable,
                                                   unitMetricK8sPodMemoryAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodMemoryAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodMemoryAvailable,
                                                    descrMetricK8sPodMemoryAvailable,
                                                    unitMetricK8sPodMemoryAvailable);
}

/**
  Deprecated, use @code k8s.pod.paging.faults @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.pod.paging.faults @endcode.", "reason": "renamed", "renamed_to":
  "k8s.pod.paging.faults"} <p> Cumulative number of major/minor page faults. This metric is derived
  from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.PageFaults</a>
  and <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.MajorPageFaults</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> counter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sPodMemoryPagingFaults =
    "k8s.pod.memory.paging.faults";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sPodMemoryPagingFaults =
    "Deprecated, use `k8s.pod.paging.faults` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sPodMemoryPagingFaults =
    "{fault}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sPodMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateUInt64Counter(kMetricK8sPodMemoryPagingFaults,
                                    descrMetricK8sPodMemoryPagingFaults,
                                    unitMetricK8sPodMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::Counter<double>>
CreateSyncDoubleMetricK8sPodMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleCounter(kMetricK8sPodMemoryPagingFaults,
                                    descrMetricK8sPodMemoryPagingFaults,
                                    unitMetricK8sPodMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableCounter(kMetricK8sPodMemoryPagingFaults,
                                             descrMetricK8sPodMemoryPagingFaults,
                                             unitMetricK8sPodMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodMemoryPagingFaults(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableCounter(kMetricK8sPodMemoryPagingFaults,
                                              descrMetricK8sPodMemoryPagingFaults,
                                              unitMetricK8sPodMemoryPagingFaults);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Pod memory RSS.
  <p>
  The amount of anonymous and swap cache memory (includes transparent hugepages).
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.RSSBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodMemoryRss     = "k8s.pod.memory.rss";
static constexpr const char *descrMetricK8sPodMemoryRss = "Pod memory RSS.";
static constexpr const char *unitMetricK8sPodMemoryRss  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodMemoryRss(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodMemoryRss, descrMetricK8sPodMemoryRss,
                                         unitMetricK8sPodMemoryRss);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodMemoryRss(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodMemoryRss, descrMetricK8sPodMemoryRss,
                                          unitMetricK8sPodMemoryRss);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodMemoryRss(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodMemoryRss, descrMetricK8sPodMemoryRss, unitMetricK8sPodMemoryRss);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodMemoryRss(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodMemoryRss, descrMetricK8sPodMemoryRss, unitMetricK8sPodMemoryRss);
}

/**
  Memory usage of the Pod.
  <p>
  Total memory in use. This includes all memory regardless of when it was accessed.
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.UsageBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodMemoryUsage     = "k8s.pod.memory.usage";
static constexpr const char *descrMetricK8sPodMemoryUsage = "Memory usage of the Pod.";
static constexpr const char *unitMetricK8sPodMemoryUsage  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodMemoryUsage, descrMetricK8sPodMemoryUsage,
                                         unitMetricK8sPodMemoryUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodMemoryUsage, descrMetricK8sPodMemoryUsage,
                                          unitMetricK8sPodMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodMemoryUsage, descrMetricK8sPodMemoryUsage, unitMetricK8sPodMemoryUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodMemoryUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodMemoryUsage, descrMetricK8sPodMemoryUsage, unitMetricK8sPodMemoryUsage);
}

/**
  Pod memory working set.
  <p>
  The amount of working set memory. This includes recently accessed memory, dirty memory, and kernel
  memory. WorkingSetBytes is <= UsageBytes. This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.WorkingSetBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodMemoryWorkingSet     = "k8s.pod.memory.working_set";
static constexpr const char *descrMetricK8sPodMemoryWorkingSet = "Pod memory working set.";
static constexpr const char *unitMetricK8sPodMemoryWorkingSet  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodMemoryWorkingSet,
                                         descrMetricK8sPodMemoryWorkingSet,
                                         unitMetricK8sPodMemoryWorkingSet);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodMemoryWorkingSet,
                                          descrMetricK8sPodMemoryWorkingSet,
                                          unitMetricK8sPodMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodMemoryWorkingSet,
                                                   descrMetricK8sPodMemoryWorkingSet,
                                                   unitMetricK8sPodMemoryWorkingSet);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodMemoryWorkingSet(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodMemoryWorkingSet,
                                                    descrMetricK8sPodMemoryWorkingSet,
                                                    unitMetricK8sPodMemoryWorkingSet);
}

/**
  Pod network errors.
  <p>
  counter
 */
static constexpr const char *kMetricK8sPodNetworkErrors     = "k8s.pod.network.errors";
static constexpr const char *descrMetricK8sPodNetworkErrors = "Pod network errors.";
static constexpr const char *unitMetricK8sPodNetworkErrors  = "{error}";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>>
CreateSyncInt64MetricK8sPodNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sPodNetworkErrors, descrMetricK8sPodNetworkErrors,
                                    unitMetricK8sPodNetworkErrors);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sPodNetworkErrors(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sPodNetworkErrors, descrMetricK8sPodNetworkErrors,
                                    unitMetricK8sPodNetworkErrors);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(
      kMetricK8sPodNetworkErrors, descrMetricK8sPodNetworkErrors, unitMetricK8sPodNetworkErrors);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodNetworkErrors(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(
      kMetricK8sPodNetworkErrors, descrMetricK8sPodNetworkErrors, unitMetricK8sPodNetworkErrors);
}

/**
  Network bytes for the Pod.
  <p>
  counter
 */
static constexpr const char *kMetricK8sPodNetworkIo     = "k8s.pod.network.io";
static constexpr const char *descrMetricK8sPodNetworkIo = "Network bytes for the Pod.";
static constexpr const char *unitMetricK8sPodNetworkIo  = "By";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>> CreateSyncInt64MetricK8sPodNetworkIo(
    metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sPodNetworkIo, descrMetricK8sPodNetworkIo,
                                    unitMetricK8sPodNetworkIo);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sPodNetworkIo(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sPodNetworkIo, descrMetricK8sPodNetworkIo,
                                    unitMetricK8sPodNetworkIo);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodNetworkIo(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(kMetricK8sPodNetworkIo, descrMetricK8sPodNetworkIo,
                                             unitMetricK8sPodNetworkIo);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodNetworkIo(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(kMetricK8sPodNetworkIo, descrMetricK8sPodNetworkIo,
                                              unitMetricK8sPodNetworkIo);
}

/**
  Pod memory paging faults.
  <p>
  Cumulative number of major/minor page faults.
  This metric is derived from the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.PageFaults</a>
  and <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#MemoryStats">MemoryStats.MajorPageFaults</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.34.0/pkg/apis/stats/v1alpha1#PodStats">PodStats.Memory</a>
  of the Kubelet's stats API. <p> counter
 */
static constexpr const char *kMetricK8sPodPagingFaults     = "k8s.pod.paging.faults";
static constexpr const char *descrMetricK8sPodPagingFaults = "Pod memory paging faults.";
static constexpr const char *unitMetricK8sPodPagingFaults  = "{fault}";

static inline nostd::unique_ptr<metrics::Counter<uint64_t>> CreateSyncInt64MetricK8sPodPagingFaults(
    metrics::Meter *meter)
{
  return meter->CreateUInt64Counter(kMetricK8sPodPagingFaults, descrMetricK8sPodPagingFaults,
                                    unitMetricK8sPodPagingFaults);
}

static inline nostd::unique_ptr<metrics::Counter<double>> CreateSyncDoubleMetricK8sPodPagingFaults(
    metrics::Meter *meter)
{
  return meter->CreateDoubleCounter(kMetricK8sPodPagingFaults, descrMetricK8sPodPagingFaults,
                                    unitMetricK8sPodPagingFaults);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodPagingFaults(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableCounter(
      kMetricK8sPodPagingFaults, descrMetricK8sPodPagingFaults, unitMetricK8sPodPagingFaults);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodPagingFaults(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableCounter(
      kMetricK8sPodPagingFaults, descrMetricK8sPodPagingFaults, unitMetricK8sPodPagingFaults);
}

/**
  Describes number of K8s Pods that are currently in a given phase.
  <p>
  All possible pod phases will be reported at each time interval to avoid missing metrics.
  Only the value corresponding to the current phase will be non-zero.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sPodStatusPhase = "k8s.pod.status.phase";
static constexpr const char *descrMetricK8sPodStatusPhase =
    "Describes number of K8s Pods that are currently in a given phase.";
static constexpr const char *unitMetricK8sPodStatusPhase = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodStatusPhase, descrMetricK8sPodStatusPhase,
                                         unitMetricK8sPodStatusPhase);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodStatusPhase, descrMetricK8sPodStatusPhase,
                                          unitMetricK8sPodStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodStatusPhase(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodStatusPhase, descrMetricK8sPodStatusPhase, unitMetricK8sPodStatusPhase);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodStatusPhase(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodStatusPhase, descrMetricK8sPodStatusPhase, unitMetricK8sPodStatusPhase);
}

/**
  Describes the number of K8s Pods that are currently in a state for a given reason.
  <p>
  All possible pod status reasons will be reported at each time interval to avoid missing metrics.
  Only the value corresponding to the current reason will be non-zero.
  <p>
  updowncounter
 */
static constexpr const char *kMetricK8sPodStatusReason = "k8s.pod.status.reason";
static constexpr const char *descrMetricK8sPodStatusReason =
    "Describes the number of K8s Pods that are currently in a state for a given reason.";
static constexpr const char *unitMetricK8sPodStatusReason = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodStatusReason(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodStatusReason, descrMetricK8sPodStatusReason,
                                         unitMetricK8sPodStatusReason);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodStatusReason(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodStatusReason, descrMetricK8sPodStatusReason,
                                          unitMetricK8sPodStatusReason);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodStatusReason(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodStatusReason, descrMetricK8sPodStatusReason, unitMetricK8sPodStatusReason);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodStatusReason(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodStatusReason, descrMetricK8sPodStatusReason, unitMetricK8sPodStatusReason);
}

/**
  The time the Pod has been running.
  <p>
  Instrumentations SHOULD use a gauge with type @code double @endcode and measure uptime in seconds
  as a floating point number with the highest precision available. The actual accuracy would depend
  on the instrumentation and operating system. <p> gauge
 */
static constexpr const char *kMetricK8sPodUptime     = "k8s.pod.uptime";
static constexpr const char *descrMetricK8sPodUptime = "The time the Pod has been running.";
static constexpr const char *unitMetricK8sPodUptime  = "s";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>> CreateSyncInt64MetricK8sPodUptime(
    metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sPodUptime, descrMetricK8sPodUptime,
                                 unitMetricK8sPodUptime);
}

static inline nostd::unique_ptr<metrics::Gauge<double>> CreateSyncDoubleMetricK8sPodUptime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sPodUptime, descrMetricK8sPodUptime,
                                  unitMetricK8sPodUptime);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncInt64MetricK8sPodUptime(
    metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sPodUptime, descrMetricK8sPodUptime,
                                           unitMetricK8sPodUptime);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument> CreateAsyncDoubleMetricK8sPodUptime(
    metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sPodUptime, descrMetricK8sPodUptime,
                                            unitMetricK8sPodUptime);
}

/**
  Pod volume storage space available.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.AvailableBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeAvailable = "k8s.pod.volume.available";
static constexpr const char *descrMetricK8sPodVolumeAvailable =
    "Pod volume storage space available.";
static constexpr const char *unitMetricK8sPodVolumeAvailable = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodVolumeAvailable,
                                         descrMetricK8sPodVolumeAvailable,
                                         unitMetricK8sPodVolumeAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodVolumeAvailable,
                                          descrMetricK8sPodVolumeAvailable,
                                          unitMetricK8sPodVolumeAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodVolumeAvailable,
                                                   descrMetricK8sPodVolumeAvailable,
                                                   unitMetricK8sPodVolumeAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodVolumeAvailable,
                                                    descrMetricK8sPodVolumeAvailable,
                                                    unitMetricK8sPodVolumeAvailable);
}

/**
  Pod volume total capacity.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.CapacityBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeCapacity     = "k8s.pod.volume.capacity";
static constexpr const char *descrMetricK8sPodVolumeCapacity = "Pod volume total capacity.";
static constexpr const char *unitMetricK8sPodVolumeCapacity  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(
      kMetricK8sPodVolumeCapacity, descrMetricK8sPodVolumeCapacity, unitMetricK8sPodVolumeCapacity);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(
      kMetricK8sPodVolumeCapacity, descrMetricK8sPodVolumeCapacity, unitMetricK8sPodVolumeCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeCapacity(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodVolumeCapacity, descrMetricK8sPodVolumeCapacity, unitMetricK8sPodVolumeCapacity);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeCapacity(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodVolumeCapacity, descrMetricK8sPodVolumeCapacity, unitMetricK8sPodVolumeCapacity);
}

/**
  The total inodes in the filesystem of the Pod's volume.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.Inodes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeInodeCount = "k8s.pod.volume.inode.count";
static constexpr const char *descrMetricK8sPodVolumeInodeCount =
    "The total inodes in the filesystem of the Pod's volume.";
static constexpr const char *unitMetricK8sPodVolumeInodeCount = "{inode}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeInodeCount(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodVolumeInodeCount,
                                         descrMetricK8sPodVolumeInodeCount,
                                         unitMetricK8sPodVolumeInodeCount);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeInodeCount(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodVolumeInodeCount,
                                          descrMetricK8sPodVolumeInodeCount,
                                          unitMetricK8sPodVolumeInodeCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeInodeCount(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodVolumeInodeCount,
                                                   descrMetricK8sPodVolumeInodeCount,
                                                   unitMetricK8sPodVolumeInodeCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeInodeCount(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodVolumeInodeCount,
                                                    descrMetricK8sPodVolumeInodeCount,
                                                    unitMetricK8sPodVolumeInodeCount);
}

/**
  The free inodes in the filesystem of the Pod's volume.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.InodesFree</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeInodeFree = "k8s.pod.volume.inode.free";
static constexpr const char *descrMetricK8sPodVolumeInodeFree =
    "The free inodes in the filesystem of the Pod's volume.";
static constexpr const char *unitMetricK8sPodVolumeInodeFree = "{inode}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeInodeFree(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodVolumeInodeFree,
                                         descrMetricK8sPodVolumeInodeFree,
                                         unitMetricK8sPodVolumeInodeFree);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeInodeFree(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodVolumeInodeFree,
                                          descrMetricK8sPodVolumeInodeFree,
                                          unitMetricK8sPodVolumeInodeFree);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeInodeFree(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodVolumeInodeFree,
                                                   descrMetricK8sPodVolumeInodeFree,
                                                   unitMetricK8sPodVolumeInodeFree);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeInodeFree(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodVolumeInodeFree,
                                                    descrMetricK8sPodVolumeInodeFree,
                                                    unitMetricK8sPodVolumeInodeFree);
}

/**
  The inodes used by the filesystem of the Pod's volume.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.InodesUsed</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> This may not be equal to @code inodes - free @endcode because
  filesystem may share inodes with other filesystems. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeInodeUsed = "k8s.pod.volume.inode.used";
static constexpr const char *descrMetricK8sPodVolumeInodeUsed =
    "The inodes used by the filesystem of the Pod's volume.";
static constexpr const char *unitMetricK8sPodVolumeInodeUsed = "{inode}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeInodeUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodVolumeInodeUsed,
                                         descrMetricK8sPodVolumeInodeUsed,
                                         unitMetricK8sPodVolumeInodeUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeInodeUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodVolumeInodeUsed,
                                          descrMetricK8sPodVolumeInodeUsed,
                                          unitMetricK8sPodVolumeInodeUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeInodeUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sPodVolumeInodeUsed,
                                                   descrMetricK8sPodVolumeInodeUsed,
                                                   unitMetricK8sPodVolumeInodeUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeInodeUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sPodVolumeInodeUsed,
                                                    descrMetricK8sPodVolumeInodeUsed,
                                                    unitMetricK8sPodVolumeInodeUsed);
}

/**
  Pod volume usage.
  <p>
  This may not equal capacity - available.
  <p>
  This metric is derived from the
  <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#VolumeStats">VolumeStats.UsedBytes</a>
  field of the <a
  href="https://pkg.go.dev/k8s.io/kubelet@v0.33.0/pkg/apis/stats/v1alpha1#PodStats">PodStats</a> of
  the Kubelet's stats API. <p> updowncounter
 */
static constexpr const char *kMetricK8sPodVolumeUsage     = "k8s.pod.volume.usage";
static constexpr const char *descrMetricK8sPodVolumeUsage = "Pod volume usage.";
static constexpr const char *unitMetricK8sPodVolumeUsage  = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sPodVolumeUsage(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sPodVolumeUsage, descrMetricK8sPodVolumeUsage,
                                         unitMetricK8sPodVolumeUsage);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sPodVolumeUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sPodVolumeUsage, descrMetricK8sPodVolumeUsage,
                                          unitMetricK8sPodVolumeUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sPodVolumeUsage(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sPodVolumeUsage, descrMetricK8sPodVolumeUsage, unitMetricK8sPodVolumeUsage);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sPodVolumeUsage(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sPodVolumeUsage, descrMetricK8sPodVolumeUsage, unitMetricK8sPodVolumeUsage);
}

/**
  Deprecated, use @code k8s.replicaset.pod.available @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicaset.pod.available @endcode.", "reason": "renamed",
  "renamed_to": "k8s.replicaset.pod.available"} <p> This metric aligns with the @code
  availableReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicasetstatus-v1-apps">K8s
  ReplicaSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicasetAvailablePods =
    "k8s.replicaset.available_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sReplicasetAvailablePods =
    "Deprecated, use `k8s.replicaset.pod.available` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sReplicasetAvailablePods =
    "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicasetAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicasetAvailablePods,
                                         descrMetricK8sReplicasetAvailablePods,
                                         unitMetricK8sReplicasetAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicasetAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicasetAvailablePods,
                                          descrMetricK8sReplicasetAvailablePods,
                                          unitMetricK8sReplicasetAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicasetAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicasetAvailablePods,
                                                   descrMetricK8sReplicasetAvailablePods,
                                                   unitMetricK8sReplicasetAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicasetAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicasetAvailablePods,
                                                    descrMetricK8sReplicasetAvailablePods,
                                                    unitMetricK8sReplicasetAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.replicaset.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicaset.pod.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.replicaset.pod.desired"} <p> This metric aligns with the @code replicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicasetspec-v1-apps">K8s
  ReplicaSetSpec</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicasetDesiredPods =
    "k8s.replicaset.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sReplicasetDesiredPods =
    "Deprecated, use `k8s.replicaset.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sReplicasetDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicasetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicasetDesiredPods,
                                         descrMetricK8sReplicasetDesiredPods,
                                         unitMetricK8sReplicasetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicasetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicasetDesiredPods,
                                          descrMetricK8sReplicasetDesiredPods,
                                          unitMetricK8sReplicasetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicasetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicasetDesiredPods,
                                                   descrMetricK8sReplicasetDesiredPods,
                                                   unitMetricK8sReplicasetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicasetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicasetDesiredPods,
                                                    descrMetricK8sReplicasetDesiredPods,
                                                    unitMetricK8sReplicasetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Total number of available replica pods (ready for at least minReadySeconds) targeted by this
  replicaset. <p> This metric aligns with the @code availableReplicas @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicasetstatus-v1-apps">K8s
  ReplicaSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sReplicasetPodAvailable = "k8s.replicaset.pod.available";
static constexpr const char *descrMetricK8sReplicasetPodAvailable =
    "Total number of available replica pods (ready for at least minReadySeconds) targeted by this "
    "replicaset.";
static constexpr const char *unitMetricK8sReplicasetPodAvailable = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicasetPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicasetPodAvailable,
                                         descrMetricK8sReplicasetPodAvailable,
                                         unitMetricK8sReplicasetPodAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicasetPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicasetPodAvailable,
                                          descrMetricK8sReplicasetPodAvailable,
                                          unitMetricK8sReplicasetPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicasetPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicasetPodAvailable,
                                                   descrMetricK8sReplicasetPodAvailable,
                                                   unitMetricK8sReplicasetPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicasetPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicasetPodAvailable,
                                                    descrMetricK8sReplicasetPodAvailable,
                                                    unitMetricK8sReplicasetPodAvailable);
}

/**
  Number of desired replica pods in this replicaset.
  <p>
  This metric aligns with the @code replicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicasetspec-v1-apps">K8s
  ReplicaSetSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sReplicasetPodDesired = "k8s.replicaset.pod.desired";
static constexpr const char *descrMetricK8sReplicasetPodDesired =
    "Number of desired replica pods in this replicaset.";
static constexpr const char *unitMetricK8sReplicasetPodDesired = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicasetPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicasetPodDesired,
                                         descrMetricK8sReplicasetPodDesired,
                                         unitMetricK8sReplicasetPodDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicasetPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicasetPodDesired,
                                          descrMetricK8sReplicasetPodDesired,
                                          unitMetricK8sReplicasetPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicasetPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicasetPodDesired,
                                                   descrMetricK8sReplicasetPodDesired,
                                                   unitMetricK8sReplicasetPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicasetPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicasetPodDesired,
                                                    descrMetricK8sReplicasetPodDesired,
                                                    unitMetricK8sReplicasetPodDesired);
}

/**
  Deprecated, use @code k8s.replicationcontroller.pod.available @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicationcontroller.pod.available @endcode.", "reason":
  "renamed", "renamed_to": "k8s.replicationcontroller.pod.available"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicationControllerAvailablePods =
    "k8s.replication_controller.available_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *descrMetricK8sReplicationControllerAvailablePods =
        "Deprecated, use `k8s.replicationcontroller.pod.available` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *unitMetricK8sReplicationControllerAvailablePods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationControllerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationControllerAvailablePods,
                                         descrMetricK8sReplicationControllerAvailablePods,
                                         unitMetricK8sReplicationControllerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationControllerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationControllerAvailablePods,
                                          descrMetricK8sReplicationControllerAvailablePods,
                                          unitMetricK8sReplicationControllerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationControllerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationControllerAvailablePods,
                                                   descrMetricK8sReplicationControllerAvailablePods,
                                                   unitMetricK8sReplicationControllerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationControllerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sReplicationControllerAvailablePods,
      descrMetricK8sReplicationControllerAvailablePods,
      unitMetricK8sReplicationControllerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.replicationcontroller.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicationcontroller.pod.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.replicationcontroller.pod.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicationControllerDesiredPods =
    "k8s.replication_controller.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *descrMetricK8sReplicationControllerDesiredPods =
        "Deprecated, use `k8s.replicationcontroller.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *unitMetricK8sReplicationControllerDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationControllerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationControllerDesiredPods,
                                         descrMetricK8sReplicationControllerDesiredPods,
                                         unitMetricK8sReplicationControllerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationControllerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationControllerDesiredPods,
                                          descrMetricK8sReplicationControllerDesiredPods,
                                          unitMetricK8sReplicationControllerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationControllerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationControllerDesiredPods,
                                                   descrMetricK8sReplicationControllerDesiredPods,
                                                   unitMetricK8sReplicationControllerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationControllerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicationControllerDesiredPods,
                                                    descrMetricK8sReplicationControllerDesiredPods,
                                                    unitMetricK8sReplicationControllerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.replicationcontroller.pod.available @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicationcontroller.pod.available @endcode.", "reason":
  "renamed", "renamed_to": "k8s.replicationcontroller.pod.available"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicationcontrollerAvailablePods =
    "k8s.replicationcontroller.available_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *descrMetricK8sReplicationcontrollerAvailablePods =
        "Deprecated, use `k8s.replicationcontroller.pod.available` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *unitMetricK8sReplicationcontrollerAvailablePods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationcontrollerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationcontrollerAvailablePods,
                                         descrMetricK8sReplicationcontrollerAvailablePods,
                                         unitMetricK8sReplicationcontrollerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationcontrollerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationcontrollerAvailablePods,
                                          descrMetricK8sReplicationcontrollerAvailablePods,
                                          unitMetricK8sReplicationcontrollerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationcontrollerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationcontrollerAvailablePods,
                                                   descrMetricK8sReplicationcontrollerAvailablePods,
                                                   unitMetricK8sReplicationcontrollerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationcontrollerAvailablePods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sReplicationcontrollerAvailablePods,
      descrMetricK8sReplicationcontrollerAvailablePods,
      unitMetricK8sReplicationcontrollerAvailablePods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.replicationcontroller.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.replicationcontroller.pod.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.replicationcontroller.pod.desired"} <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sReplicationcontrollerDesiredPods =
    "k8s.replicationcontroller.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *descrMetricK8sReplicationcontrollerDesiredPods =
        "Deprecated, use `k8s.replicationcontroller.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char
    *unitMetricK8sReplicationcontrollerDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationcontrollerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationcontrollerDesiredPods,
                                         descrMetricK8sReplicationcontrollerDesiredPods,
                                         unitMetricK8sReplicationcontrollerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationcontrollerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationcontrollerDesiredPods,
                                          descrMetricK8sReplicationcontrollerDesiredPods,
                                          unitMetricK8sReplicationcontrollerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationcontrollerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationcontrollerDesiredPods,
                                                   descrMetricK8sReplicationcontrollerDesiredPods,
                                                   unitMetricK8sReplicationcontrollerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationcontrollerDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicationcontrollerDesiredPods,
                                                    descrMetricK8sReplicationcontrollerDesiredPods,
                                                    unitMetricK8sReplicationcontrollerDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Total number of available replica pods (ready for at least minReadySeconds) targeted by this
  replication controller. <p> This metric aligns with the @code availableReplicas @endcode field of
  the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicationcontrollerstatus-v1-core">K8s
  ReplicationControllerStatus</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sReplicationcontrollerPodAvailable =
    "k8s.replicationcontroller.pod.available";
static constexpr const char *descrMetricK8sReplicationcontrollerPodAvailable =
    "Total number of available replica pods (ready for at least minReadySeconds) targeted by this "
    "replication controller.";
static constexpr const char *unitMetricK8sReplicationcontrollerPodAvailable = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationcontrollerPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationcontrollerPodAvailable,
                                         descrMetricK8sReplicationcontrollerPodAvailable,
                                         unitMetricK8sReplicationcontrollerPodAvailable);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationcontrollerPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationcontrollerPodAvailable,
                                          descrMetricK8sReplicationcontrollerPodAvailable,
                                          unitMetricK8sReplicationcontrollerPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationcontrollerPodAvailable(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationcontrollerPodAvailable,
                                                   descrMetricK8sReplicationcontrollerPodAvailable,
                                                   unitMetricK8sReplicationcontrollerPodAvailable);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationcontrollerPodAvailable(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicationcontrollerPodAvailable,
                                                    descrMetricK8sReplicationcontrollerPodAvailable,
                                                    unitMetricK8sReplicationcontrollerPodAvailable);
}

/**
  Number of desired replica pods in this replication controller.
  <p>
  This metric aligns with the @code replicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#replicationcontrollerspec-v1-core">K8s
  ReplicationControllerSpec</a> <p> updowncounter
 */
static constexpr const char *kMetricK8sReplicationcontrollerPodDesired =
    "k8s.replicationcontroller.pod.desired";
static constexpr const char *descrMetricK8sReplicationcontrollerPodDesired =
    "Number of desired replica pods in this replication controller.";
static constexpr const char *unitMetricK8sReplicationcontrollerPodDesired = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sReplicationcontrollerPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sReplicationcontrollerPodDesired,
                                         descrMetricK8sReplicationcontrollerPodDesired,
                                         unitMetricK8sReplicationcontrollerPodDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sReplicationcontrollerPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sReplicationcontrollerPodDesired,
                                          descrMetricK8sReplicationcontrollerPodDesired,
                                          unitMetricK8sReplicationcontrollerPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sReplicationcontrollerPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sReplicationcontrollerPodDesired,
                                                   descrMetricK8sReplicationcontrollerPodDesired,
                                                   unitMetricK8sReplicationcontrollerPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sReplicationcontrollerPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sReplicationcontrollerPodDesired,
                                                    descrMetricK8sReplicationcontrollerPodDesired,
                                                    unitMetricK8sReplicationcontrollerPodDesired);
}

/**
  The CPU limits in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaCpuLimitHard =
    "k8s.resourcequota.cpu.limit.hard";
static constexpr const char *descrMetricK8sResourcequotaCpuLimitHard =
    "The CPU limits in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaCpuLimitHard = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaCpuLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaCpuLimitHard,
                                         descrMetricK8sResourcequotaCpuLimitHard,
                                         unitMetricK8sResourcequotaCpuLimitHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaCpuLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaCpuLimitHard,
                                          descrMetricK8sResourcequotaCpuLimitHard,
                                          unitMetricK8sResourcequotaCpuLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaCpuLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaCpuLimitHard,
                                                   descrMetricK8sResourcequotaCpuLimitHard,
                                                   unitMetricK8sResourcequotaCpuLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaCpuLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaCpuLimitHard,
                                                    descrMetricK8sResourcequotaCpuLimitHard,
                                                    unitMetricK8sResourcequotaCpuLimitHard);
}

/**
  The CPU limits in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaCpuLimitUsed =
    "k8s.resourcequota.cpu.limit.used";
static constexpr const char *descrMetricK8sResourcequotaCpuLimitUsed =
    "The CPU limits in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaCpuLimitUsed = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaCpuLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaCpuLimitUsed,
                                         descrMetricK8sResourcequotaCpuLimitUsed,
                                         unitMetricK8sResourcequotaCpuLimitUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaCpuLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaCpuLimitUsed,
                                          descrMetricK8sResourcequotaCpuLimitUsed,
                                          unitMetricK8sResourcequotaCpuLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaCpuLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaCpuLimitUsed,
                                                   descrMetricK8sResourcequotaCpuLimitUsed,
                                                   unitMetricK8sResourcequotaCpuLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaCpuLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaCpuLimitUsed,
                                                    descrMetricK8sResourcequotaCpuLimitUsed,
                                                    unitMetricK8sResourcequotaCpuLimitUsed);
}

/**
  The CPU requests in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaCpuRequestHard =
    "k8s.resourcequota.cpu.request.hard";
static constexpr const char *descrMetricK8sResourcequotaCpuRequestHard =
    "The CPU requests in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaCpuRequestHard = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaCpuRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaCpuRequestHard,
                                         descrMetricK8sResourcequotaCpuRequestHard,
                                         unitMetricK8sResourcequotaCpuRequestHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaCpuRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaCpuRequestHard,
                                          descrMetricK8sResourcequotaCpuRequestHard,
                                          unitMetricK8sResourcequotaCpuRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaCpuRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaCpuRequestHard,
                                                   descrMetricK8sResourcequotaCpuRequestHard,
                                                   unitMetricK8sResourcequotaCpuRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaCpuRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaCpuRequestHard,
                                                    descrMetricK8sResourcequotaCpuRequestHard,
                                                    unitMetricK8sResourcequotaCpuRequestHard);
}

/**
  The CPU requests in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaCpuRequestUsed =
    "k8s.resourcequota.cpu.request.used";
static constexpr const char *descrMetricK8sResourcequotaCpuRequestUsed =
    "The CPU requests in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaCpuRequestUsed = "{cpu}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaCpuRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaCpuRequestUsed,
                                         descrMetricK8sResourcequotaCpuRequestUsed,
                                         unitMetricK8sResourcequotaCpuRequestUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaCpuRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaCpuRequestUsed,
                                          descrMetricK8sResourcequotaCpuRequestUsed,
                                          unitMetricK8sResourcequotaCpuRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaCpuRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaCpuRequestUsed,
                                                   descrMetricK8sResourcequotaCpuRequestUsed,
                                                   unitMetricK8sResourcequotaCpuRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaCpuRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaCpuRequestUsed,
                                                    descrMetricK8sResourcequotaCpuRequestUsed,
                                                    unitMetricK8sResourcequotaCpuRequestUsed);
}

/**
  The sum of local ephemeral storage limits in the namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaEphemeralStorageLimitHard =
    "k8s.resourcequota.ephemeral_storage.limit.hard";
static constexpr const char *descrMetricK8sResourcequotaEphemeralStorageLimitHard =
    "The sum of local ephemeral storage limits in the namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaEphemeralStorageLimitHard = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaEphemeralStorageLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaEphemeralStorageLimitHard,
                                         descrMetricK8sResourcequotaEphemeralStorageLimitHard,
                                         unitMetricK8sResourcequotaEphemeralStorageLimitHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaEphemeralStorageLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaEphemeralStorageLimitHard,
                                          descrMetricK8sResourcequotaEphemeralStorageLimitHard,
                                          unitMetricK8sResourcequotaEphemeralStorageLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaEphemeralStorageLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageLimitHard,
      descrMetricK8sResourcequotaEphemeralStorageLimitHard,
      unitMetricK8sResourcequotaEphemeralStorageLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaEphemeralStorageLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageLimitHard,
      descrMetricK8sResourcequotaEphemeralStorageLimitHard,
      unitMetricK8sResourcequotaEphemeralStorageLimitHard);
}

/**
  The sum of local ephemeral storage limits in the namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaEphemeralStorageLimitUsed =
    "k8s.resourcequota.ephemeral_storage.limit.used";
static constexpr const char *descrMetricK8sResourcequotaEphemeralStorageLimitUsed =
    "The sum of local ephemeral storage limits in the namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaEphemeralStorageLimitUsed = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaEphemeralStorageLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaEphemeralStorageLimitUsed,
                                         descrMetricK8sResourcequotaEphemeralStorageLimitUsed,
                                         unitMetricK8sResourcequotaEphemeralStorageLimitUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaEphemeralStorageLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaEphemeralStorageLimitUsed,
                                          descrMetricK8sResourcequotaEphemeralStorageLimitUsed,
                                          unitMetricK8sResourcequotaEphemeralStorageLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaEphemeralStorageLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageLimitUsed,
      descrMetricK8sResourcequotaEphemeralStorageLimitUsed,
      unitMetricK8sResourcequotaEphemeralStorageLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaEphemeralStorageLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageLimitUsed,
      descrMetricK8sResourcequotaEphemeralStorageLimitUsed,
      unitMetricK8sResourcequotaEphemeralStorageLimitUsed);
}

/**
  The sum of local ephemeral storage requests in the namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaEphemeralStorageRequestHard =
    "k8s.resourcequota.ephemeral_storage.request.hard";
static constexpr const char *descrMetricK8sResourcequotaEphemeralStorageRequestHard =
    "The sum of local ephemeral storage requests in the namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaEphemeralStorageRequestHard = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaEphemeralStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaEphemeralStorageRequestHard,
                                         descrMetricK8sResourcequotaEphemeralStorageRequestHard,
                                         unitMetricK8sResourcequotaEphemeralStorageRequestHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaEphemeralStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaEphemeralStorageRequestHard,
                                          descrMetricK8sResourcequotaEphemeralStorageRequestHard,
                                          unitMetricK8sResourcequotaEphemeralStorageRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaEphemeralStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageRequestHard,
      descrMetricK8sResourcequotaEphemeralStorageRequestHard,
      unitMetricK8sResourcequotaEphemeralStorageRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaEphemeralStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageRequestHard,
      descrMetricK8sResourcequotaEphemeralStorageRequestHard,
      unitMetricK8sResourcequotaEphemeralStorageRequestHard);
}

/**
  The sum of local ephemeral storage requests in the namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaEphemeralStorageRequestUsed =
    "k8s.resourcequota.ephemeral_storage.request.used";
static constexpr const char *descrMetricK8sResourcequotaEphemeralStorageRequestUsed =
    "The sum of local ephemeral storage requests in the namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaEphemeralStorageRequestUsed = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaEphemeralStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaEphemeralStorageRequestUsed,
                                         descrMetricK8sResourcequotaEphemeralStorageRequestUsed,
                                         unitMetricK8sResourcequotaEphemeralStorageRequestUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaEphemeralStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaEphemeralStorageRequestUsed,
                                          descrMetricK8sResourcequotaEphemeralStorageRequestUsed,
                                          unitMetricK8sResourcequotaEphemeralStorageRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaEphemeralStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageRequestUsed,
      descrMetricK8sResourcequotaEphemeralStorageRequestUsed,
      unitMetricK8sResourcequotaEphemeralStorageRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaEphemeralStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaEphemeralStorageRequestUsed,
      descrMetricK8sResourcequotaEphemeralStorageRequestUsed,
      unitMetricK8sResourcequotaEphemeralStorageRequestUsed);
}

/**
  The huge page requests in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaHugepageCountRequestHard =
    "k8s.resourcequota.hugepage_count.request.hard";
static constexpr const char *descrMetricK8sResourcequotaHugepageCountRequestHard =
    "The huge page requests in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaHugepageCountRequestHard = "{hugepage}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaHugepageCountRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaHugepageCountRequestHard,
                                         descrMetricK8sResourcequotaHugepageCountRequestHard,
                                         unitMetricK8sResourcequotaHugepageCountRequestHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaHugepageCountRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaHugepageCountRequestHard,
                                          descrMetricK8sResourcequotaHugepageCountRequestHard,
                                          unitMetricK8sResourcequotaHugepageCountRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaHugepageCountRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaHugepageCountRequestHard,
      descrMetricK8sResourcequotaHugepageCountRequestHard,
      unitMetricK8sResourcequotaHugepageCountRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaHugepageCountRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaHugepageCountRequestHard,
      descrMetricK8sResourcequotaHugepageCountRequestHard,
      unitMetricK8sResourcequotaHugepageCountRequestHard);
}

/**
  The huge page requests in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaHugepageCountRequestUsed =
    "k8s.resourcequota.hugepage_count.request.used";
static constexpr const char *descrMetricK8sResourcequotaHugepageCountRequestUsed =
    "The huge page requests in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaHugepageCountRequestUsed = "{hugepage}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaHugepageCountRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaHugepageCountRequestUsed,
                                         descrMetricK8sResourcequotaHugepageCountRequestUsed,
                                         unitMetricK8sResourcequotaHugepageCountRequestUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaHugepageCountRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaHugepageCountRequestUsed,
                                          descrMetricK8sResourcequotaHugepageCountRequestUsed,
                                          unitMetricK8sResourcequotaHugepageCountRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaHugepageCountRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaHugepageCountRequestUsed,
      descrMetricK8sResourcequotaHugepageCountRequestUsed,
      unitMetricK8sResourcequotaHugepageCountRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaHugepageCountRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaHugepageCountRequestUsed,
      descrMetricK8sResourcequotaHugepageCountRequestUsed,
      unitMetricK8sResourcequotaHugepageCountRequestUsed);
}

/**
  The memory limits in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaMemoryLimitHard =
    "k8s.resourcequota.memory.limit.hard";
static constexpr const char *descrMetricK8sResourcequotaMemoryLimitHard =
    "The memory limits in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaMemoryLimitHard = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaMemoryLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaMemoryLimitHard,
                                         descrMetricK8sResourcequotaMemoryLimitHard,
                                         unitMetricK8sResourcequotaMemoryLimitHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaMemoryLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaMemoryLimitHard,
                                          descrMetricK8sResourcequotaMemoryLimitHard,
                                          unitMetricK8sResourcequotaMemoryLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaMemoryLimitHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaMemoryLimitHard,
                                                   descrMetricK8sResourcequotaMemoryLimitHard,
                                                   unitMetricK8sResourcequotaMemoryLimitHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaMemoryLimitHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaMemoryLimitHard,
                                                    descrMetricK8sResourcequotaMemoryLimitHard,
                                                    unitMetricK8sResourcequotaMemoryLimitHard);
}

/**
  The memory limits in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaMemoryLimitUsed =
    "k8s.resourcequota.memory.limit.used";
static constexpr const char *descrMetricK8sResourcequotaMemoryLimitUsed =
    "The memory limits in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaMemoryLimitUsed = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaMemoryLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaMemoryLimitUsed,
                                         descrMetricK8sResourcequotaMemoryLimitUsed,
                                         unitMetricK8sResourcequotaMemoryLimitUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaMemoryLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaMemoryLimitUsed,
                                          descrMetricK8sResourcequotaMemoryLimitUsed,
                                          unitMetricK8sResourcequotaMemoryLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaMemoryLimitUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaMemoryLimitUsed,
                                                   descrMetricK8sResourcequotaMemoryLimitUsed,
                                                   unitMetricK8sResourcequotaMemoryLimitUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaMemoryLimitUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaMemoryLimitUsed,
                                                    descrMetricK8sResourcequotaMemoryLimitUsed,
                                                    unitMetricK8sResourcequotaMemoryLimitUsed);
}

/**
  The memory requests in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaMemoryRequestHard =
    "k8s.resourcequota.memory.request.hard";
static constexpr const char *descrMetricK8sResourcequotaMemoryRequestHard =
    "The memory requests in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaMemoryRequestHard = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaMemoryRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaMemoryRequestHard,
                                         descrMetricK8sResourcequotaMemoryRequestHard,
                                         unitMetricK8sResourcequotaMemoryRequestHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaMemoryRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaMemoryRequestHard,
                                          descrMetricK8sResourcequotaMemoryRequestHard,
                                          unitMetricK8sResourcequotaMemoryRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaMemoryRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaMemoryRequestHard,
                                                   descrMetricK8sResourcequotaMemoryRequestHard,
                                                   unitMetricK8sResourcequotaMemoryRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaMemoryRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaMemoryRequestHard,
                                                    descrMetricK8sResourcequotaMemoryRequestHard,
                                                    unitMetricK8sResourcequotaMemoryRequestHard);
}

/**
  The memory requests in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaMemoryRequestUsed =
    "k8s.resourcequota.memory.request.used";
static constexpr const char *descrMetricK8sResourcequotaMemoryRequestUsed =
    "The memory requests in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaMemoryRequestUsed = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaMemoryRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaMemoryRequestUsed,
                                         descrMetricK8sResourcequotaMemoryRequestUsed,
                                         unitMetricK8sResourcequotaMemoryRequestUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaMemoryRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaMemoryRequestUsed,
                                          descrMetricK8sResourcequotaMemoryRequestUsed,
                                          unitMetricK8sResourcequotaMemoryRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaMemoryRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaMemoryRequestUsed,
                                                   descrMetricK8sResourcequotaMemoryRequestUsed,
                                                   unitMetricK8sResourcequotaMemoryRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaMemoryRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaMemoryRequestUsed,
                                                    descrMetricK8sResourcequotaMemoryRequestUsed,
                                                    unitMetricK8sResourcequotaMemoryRequestUsed);
}

/**
  The object count limits in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaObjectCountHard =
    "k8s.resourcequota.object_count.hard";
static constexpr const char *descrMetricK8sResourcequotaObjectCountHard =
    "The object count limits in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaObjectCountHard = "{object}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaObjectCountHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaObjectCountHard,
                                         descrMetricK8sResourcequotaObjectCountHard,
                                         unitMetricK8sResourcequotaObjectCountHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaObjectCountHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaObjectCountHard,
                                          descrMetricK8sResourcequotaObjectCountHard,
                                          unitMetricK8sResourcequotaObjectCountHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaObjectCountHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaObjectCountHard,
                                                   descrMetricK8sResourcequotaObjectCountHard,
                                                   unitMetricK8sResourcequotaObjectCountHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaObjectCountHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaObjectCountHard,
                                                    descrMetricK8sResourcequotaObjectCountHard,
                                                    unitMetricK8sResourcequotaObjectCountHard);
}

/**
  The object count limits in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaObjectCountUsed =
    "k8s.resourcequota.object_count.used";
static constexpr const char *descrMetricK8sResourcequotaObjectCountUsed =
    "The object count limits in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaObjectCountUsed = "{object}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaObjectCountUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaObjectCountUsed,
                                         descrMetricK8sResourcequotaObjectCountUsed,
                                         unitMetricK8sResourcequotaObjectCountUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaObjectCountUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaObjectCountUsed,
                                          descrMetricK8sResourcequotaObjectCountUsed,
                                          unitMetricK8sResourcequotaObjectCountUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaObjectCountUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaObjectCountUsed,
                                                   descrMetricK8sResourcequotaObjectCountUsed,
                                                   unitMetricK8sResourcequotaObjectCountUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaObjectCountUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaObjectCountUsed,
                                                    descrMetricK8sResourcequotaObjectCountUsed,
                                                    unitMetricK8sResourcequotaObjectCountUsed);
}

/**
  The total number of PersistentVolumeClaims that can exist in the namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> The @code k8s.storageclass.name @endcode should be required when a
  resource quota is defined for a specific storage class. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaPersistentvolumeclaimCountHard =
    "k8s.resourcequota.persistentvolumeclaim_count.hard";
static constexpr const char *descrMetricK8sResourcequotaPersistentvolumeclaimCountHard =
    "The total number of PersistentVolumeClaims that can exist in the namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaPersistentvolumeclaimCountHard =
        "{persistentvolumeclaim}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaPersistentvolumeclaimCountHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaPersistentvolumeclaimCountHard,
                                         descrMetricK8sResourcequotaPersistentvolumeclaimCountHard,
                                         unitMetricK8sResourcequotaPersistentvolumeclaimCountHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaPersistentvolumeclaimCountHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaPersistentvolumeclaimCountHard,
                                          descrMetricK8sResourcequotaPersistentvolumeclaimCountHard,
                                          unitMetricK8sResourcequotaPersistentvolumeclaimCountHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaPersistentvolumeclaimCountHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaPersistentvolumeclaimCountHard,
      descrMetricK8sResourcequotaPersistentvolumeclaimCountHard,
      unitMetricK8sResourcequotaPersistentvolumeclaimCountHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaPersistentvolumeclaimCountHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaPersistentvolumeclaimCountHard,
      descrMetricK8sResourcequotaPersistentvolumeclaimCountHard,
      unitMetricK8sResourcequotaPersistentvolumeclaimCountHard);
}

/**
  The total number of PersistentVolumeClaims that can exist in the namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> The @code k8s.storageclass.name @endcode should be required when a
  resource quota is defined for a specific storage class. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaPersistentvolumeclaimCountUsed =
    "k8s.resourcequota.persistentvolumeclaim_count.used";
static constexpr const char *descrMetricK8sResourcequotaPersistentvolumeclaimCountUsed =
    "The total number of PersistentVolumeClaims that can exist in the namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaPersistentvolumeclaimCountUsed =
        "{persistentvolumeclaim}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaPersistentvolumeclaimCountUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
                                         descrMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
                                         unitMetricK8sResourcequotaPersistentvolumeclaimCountUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaPersistentvolumeclaimCountUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
                                          descrMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
                                          unitMetricK8sResourcequotaPersistentvolumeclaimCountUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaPersistentvolumeclaimCountUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(
      kMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
      descrMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
      unitMetricK8sResourcequotaPersistentvolumeclaimCountUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaPersistentvolumeclaimCountUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(
      kMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
      descrMetricK8sResourcequotaPersistentvolumeclaimCountUsed,
      unitMetricK8sResourcequotaPersistentvolumeclaimCountUsed);
}

/**
  The storage requests in a specific namespace.
  The value represents the configured quota limit of the resource in the namespace.
  <p>
  This metric is retrieved from the @code hard @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> The @code k8s.storageclass.name @endcode should be required when a
  resource quota is defined for a specific storage class. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaStorageRequestHard =
    "k8s.resourcequota.storage.request.hard";
static constexpr const char *descrMetricK8sResourcequotaStorageRequestHard =
    "The storage requests in a specific namespace.
    The value represents the configured quota limit of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaStorageRequestHard = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaStorageRequestHard,
                                         descrMetricK8sResourcequotaStorageRequestHard,
                                         unitMetricK8sResourcequotaStorageRequestHard);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaStorageRequestHard,
                                          descrMetricK8sResourcequotaStorageRequestHard,
                                          unitMetricK8sResourcequotaStorageRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaStorageRequestHard,
                                                   descrMetricK8sResourcequotaStorageRequestHard,
                                                   unitMetricK8sResourcequotaStorageRequestHard);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaStorageRequestHard(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaStorageRequestHard,
                                                    descrMetricK8sResourcequotaStorageRequestHard,
                                                    unitMetricK8sResourcequotaStorageRequestHard);
}

/**
  The storage requests in a specific namespace.
  The value represents the current observed total usage of the resource in the namespace.
  <p>
  This metric is retrieved from the @code used @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#resourcequotastatus-v1-core">K8s
  ResourceQuotaStatus</a>. <p> The @code k8s.storageclass.name @endcode should be required when a
  resource quota is defined for a specific storage class. <p> updowncounter
 */
static constexpr const char *kMetricK8sResourcequotaStorageRequestUsed =
    "k8s.resourcequota.storage.request.used";
static constexpr const char *descrMetricK8sResourcequotaStorageRequestUsed =
    "The storage requests in a specific namespace.
    The value represents the current observed total usage of the resource in the namespace.";
    static constexpr const char *unitMetricK8sResourcequotaStorageRequestUsed = "By";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sResourcequotaStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sResourcequotaStorageRequestUsed,
                                         descrMetricK8sResourcequotaStorageRequestUsed,
                                         unitMetricK8sResourcequotaStorageRequestUsed);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sResourcequotaStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sResourcequotaStorageRequestUsed,
                                          descrMetricK8sResourcequotaStorageRequestUsed,
                                          unitMetricK8sResourcequotaStorageRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sResourcequotaStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sResourcequotaStorageRequestUsed,
                                                   descrMetricK8sResourcequotaStorageRequestUsed,
                                                   unitMetricK8sResourcequotaStorageRequestUsed);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sResourcequotaStorageRequestUsed(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sResourcequotaStorageRequestUsed,
                                                    descrMetricK8sResourcequotaStorageRequestUsed,
                                                    unitMetricK8sResourcequotaStorageRequestUsed);
}

/**
  Number of endpoints for a service by condition and address type.
  <p>
  This metric is derived from the Kubernetes <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/service-resources/endpoint-slice-v1/">EndpointSlice
  API</a>. It reports the number of network endpoints backing a Service, broken down by their
  condition and address type. <p> In dual-stack or multi-protocol clusters, separate counts are
  reported for each address family (@code IPv4 @endcode, @code IPv6 @endcode, @code FQDN @endcode).
  <p>
  When the optional @code zone @endcode attribute is enabled, counts are further broken down by
  availability zone for zone-aware monitoring. <p> An endpoint may be reported under multiple
  conditions simultaneously (e.g., both @code serving @endcode and @code terminating @endcode during
  a graceful shutdown). See <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/service-resources/endpoint-slice-v1/">K8s
  EndpointConditions</a> for more details. <p> The conditions represent: <ul> <li>@code ready
  @endcode: Endpoints capable of receiving new connections.</li> <li>@code serving @endcode:
  Endpoints currently handling traffic.</li> <li>@code terminating @endcode: Endpoints that are
  being phased out but may still be handling existing connections.</li>
  </ul>
  <p>
  For Services with @code publishNotReadyAddresses @endcode enabled (common for headless
  StatefulSets), this metric will include endpoints that are published despite not being ready. The
  @code k8s.service.publish_not_ready_addresses @endcode resource attribute indicates this setting.
  <p>
  gauge
 */
static constexpr const char *kMetricK8sServiceEndpointCount = "k8s.service.endpoint.count";
static constexpr const char *descrMetricK8sServiceEndpointCount =
    "Number of endpoints for a service by condition and address type.";
static constexpr const char *unitMetricK8sServiceEndpointCount = "{endpoint}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sServiceEndpointCount(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sServiceEndpointCount, descrMetricK8sServiceEndpointCount,
                                 unitMetricK8sServiceEndpointCount);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sServiceEndpointCount(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sServiceEndpointCount,
                                  descrMetricK8sServiceEndpointCount,
                                  unitMetricK8sServiceEndpointCount);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sServiceEndpointCount(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sServiceEndpointCount,
                                           descrMetricK8sServiceEndpointCount,
                                           unitMetricK8sServiceEndpointCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sServiceEndpointCount(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sServiceEndpointCount,
                                            descrMetricK8sServiceEndpointCount,
                                            unitMetricK8sServiceEndpointCount);
}

/**
  Number of load balancer ingress points (external IPs/hostnames) assigned to the service.
  <p>
  This metric reports the number of external ingress points (IP addresses or hostnames)
  assigned to a LoadBalancer Service.
  <p>
  It is only emitted for Services of type @code LoadBalancer @endcode and reflects the assignments
  made by the underlying infrastructure's load balancer controller in the
  <a
  href="https://kubernetes.io/docs/reference/kubernetes-api/service-resources/service-v1/#ServiceStatus">.status.loadBalancer.ingress</a>
  field. <p> A value of @code 0 @endcode indicates that no ingress points have been assigned yet
  (e.g., during provisioning). A value greater than @code 1 @endcode may occur when multiple IPs or
  hostnames are assigned (e.g., dual-stack configurations). <p> This metric signals that external
  endpoints have been assigned by the load balancer controller, but it does not guarantee that the
  load balancer is healthy. <p> gauge
 */
static constexpr const char *kMetricK8sServiceLoadBalancerIngressCount =
    "k8s.service.load_balancer.ingress.count";
static constexpr const char *descrMetricK8sServiceLoadBalancerIngressCount =
    "Number of load balancer ingress points (external IPs/hostnames) assigned to the service.";
static constexpr const char *unitMetricK8sServiceLoadBalancerIngressCount = "{ingress}";

#if OPENTELEMETRY_ABI_VERSION_NO >= 2

static inline nostd::unique_ptr<metrics::Gauge<int64_t>>
CreateSyncInt64MetricK8sServiceLoadBalancerIngressCount(metrics::Meter *meter)
{
  return meter->CreateInt64Gauge(kMetricK8sServiceLoadBalancerIngressCount,
                                 descrMetricK8sServiceLoadBalancerIngressCount,
                                 unitMetricK8sServiceLoadBalancerIngressCount);
}

static inline nostd::unique_ptr<metrics::Gauge<double>>
CreateSyncDoubleMetricK8sServiceLoadBalancerIngressCount(metrics::Meter *meter)
{
  return meter->CreateDoubleGauge(kMetricK8sServiceLoadBalancerIngressCount,
                                  descrMetricK8sServiceLoadBalancerIngressCount,
                                  unitMetricK8sServiceLoadBalancerIngressCount);
}
#endif /* OPENTELEMETRY_ABI_VERSION_NO */

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sServiceLoadBalancerIngressCount(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableGauge(kMetricK8sServiceLoadBalancerIngressCount,
                                           descrMetricK8sServiceLoadBalancerIngressCount,
                                           unitMetricK8sServiceLoadBalancerIngressCount);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sServiceLoadBalancerIngressCount(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableGauge(kMetricK8sServiceLoadBalancerIngressCount,
                                            descrMetricK8sServiceLoadBalancerIngressCount,
                                            unitMetricK8sServiceLoadBalancerIngressCount);
}

/**
  Deprecated, use @code k8s.statefulset.pod.current @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.statefulset.pod.current @endcode.", "reason": "renamed",
  "renamed_to": "k8s.statefulset.pod.current"} <p> This metric aligns with the @code currentReplicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sStatefulsetCurrentPods =
    "k8s.statefulset.current_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sStatefulsetCurrentPods =
    "Deprecated, use `k8s.statefulset.pod.current` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sStatefulsetCurrentPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetCurrentPods,
                                         descrMetricK8sStatefulsetCurrentPods,
                                         unitMetricK8sStatefulsetCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetCurrentPods,
                                          descrMetricK8sStatefulsetCurrentPods,
                                          unitMetricK8sStatefulsetCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetCurrentPods,
                                                   descrMetricK8sStatefulsetCurrentPods,
                                                   unitMetricK8sStatefulsetCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetCurrentPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetCurrentPods,
                                                    descrMetricK8sStatefulsetCurrentPods,
                                                    unitMetricK8sStatefulsetCurrentPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.statefulset.pod.desired @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.statefulset.pod.desired @endcode.", "reason": "renamed",
  "renamed_to": "k8s.statefulset.pod.desired"} <p> This metric aligns with the @code replicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetspec-v1-apps">K8s
  StatefulSetSpec</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sStatefulsetDesiredPods =
    "k8s.statefulset.desired_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sStatefulsetDesiredPods =
    "Deprecated, use `k8s.statefulset.pod.desired` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sStatefulsetDesiredPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetDesiredPods,
                                         descrMetricK8sStatefulsetDesiredPods,
                                         unitMetricK8sStatefulsetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetDesiredPods,
                                          descrMetricK8sStatefulsetDesiredPods,
                                          unitMetricK8sStatefulsetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetDesiredPods,
                                                   descrMetricK8sStatefulsetDesiredPods,
                                                   unitMetricK8sStatefulsetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetDesiredPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetDesiredPods,
                                                    descrMetricK8sStatefulsetDesiredPods,
                                                    unitMetricK8sStatefulsetDesiredPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  The number of replica pods created by the statefulset controller from the statefulset version
  indicated by currentRevision. <p> This metric aligns with the @code currentReplicas @endcode field
  of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sStatefulsetPodCurrent = "k8s.statefulset.pod.current";
static constexpr const char *descrMetricK8sStatefulsetPodCurrent =
    "The number of replica pods created by the statefulset controller from the statefulset version "
    "indicated by currentRevision.";
static constexpr const char *unitMetricK8sStatefulsetPodCurrent = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetPodCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetPodCurrent,
                                         descrMetricK8sStatefulsetPodCurrent,
                                         unitMetricK8sStatefulsetPodCurrent);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetPodCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetPodCurrent,
                                          descrMetricK8sStatefulsetPodCurrent,
                                          unitMetricK8sStatefulsetPodCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetPodCurrent(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetPodCurrent,
                                                   descrMetricK8sStatefulsetPodCurrent,
                                                   unitMetricK8sStatefulsetPodCurrent);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetPodCurrent(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetPodCurrent,
                                                    descrMetricK8sStatefulsetPodCurrent,
                                                    unitMetricK8sStatefulsetPodCurrent);
}

/**
  Number of desired replica pods in this statefulset.
  <p>
  This metric aligns with the @code replicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetspec-v1-apps">K8s
  StatefulSetSpec</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sStatefulsetPodDesired = "k8s.statefulset.pod.desired";
static constexpr const char *descrMetricK8sStatefulsetPodDesired =
    "Number of desired replica pods in this statefulset.";
static constexpr const char *unitMetricK8sStatefulsetPodDesired = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetPodDesired,
                                         descrMetricK8sStatefulsetPodDesired,
                                         unitMetricK8sStatefulsetPodDesired);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetPodDesired,
                                          descrMetricK8sStatefulsetPodDesired,
                                          unitMetricK8sStatefulsetPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetPodDesired(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetPodDesired,
                                                   descrMetricK8sStatefulsetPodDesired,
                                                   unitMetricK8sStatefulsetPodDesired);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetPodDesired(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetPodDesired,
                                                    descrMetricK8sStatefulsetPodDesired,
                                                    unitMetricK8sStatefulsetPodDesired);
}

/**
  The number of replica pods created for this statefulset with a Ready Condition.
  <p>
  This metric aligns with the @code readyReplicas @endcode field of the
  <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sStatefulsetPodReady = "k8s.statefulset.pod.ready";
static constexpr const char *descrMetricK8sStatefulsetPodReady =
    "The number of replica pods created for this statefulset with a Ready Condition.";
static constexpr const char *unitMetricK8sStatefulsetPodReady = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetPodReady(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetPodReady,
                                         descrMetricK8sStatefulsetPodReady,
                                         unitMetricK8sStatefulsetPodReady);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetPodReady(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetPodReady,
                                          descrMetricK8sStatefulsetPodReady,
                                          unitMetricK8sStatefulsetPodReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetPodReady(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetPodReady,
                                                   descrMetricK8sStatefulsetPodReady,
                                                   unitMetricK8sStatefulsetPodReady);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetPodReady(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetPodReady,
                                                    descrMetricK8sStatefulsetPodReady,
                                                    unitMetricK8sStatefulsetPodReady);
}

/**
  Number of replica pods created by the statefulset controller from the statefulset version
  indicated by updateRevision. <p> This metric aligns with the @code updatedReplicas @endcode field
  of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
static constexpr const char *kMetricK8sStatefulsetPodUpdated = "k8s.statefulset.pod.updated";
static constexpr const char *descrMetricK8sStatefulsetPodUpdated =
    "Number of replica pods created by the statefulset controller from the statefulset version "
    "indicated by updateRevision.";
static constexpr const char *unitMetricK8sStatefulsetPodUpdated = "{pod}";

static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetPodUpdated(metrics::Meter *meter)
{
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetPodUpdated,
                                         descrMetricK8sStatefulsetPodUpdated,
                                         unitMetricK8sStatefulsetPodUpdated);
}

static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetPodUpdated(metrics::Meter *meter)
{
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetPodUpdated,
                                          descrMetricK8sStatefulsetPodUpdated,
                                          unitMetricK8sStatefulsetPodUpdated);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetPodUpdated(metrics::Meter *meter)
{
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetPodUpdated,
                                                   descrMetricK8sStatefulsetPodUpdated,
                                                   unitMetricK8sStatefulsetPodUpdated);
}

static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetPodUpdated(metrics::Meter *meter)
{
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetPodUpdated,
                                                    descrMetricK8sStatefulsetPodUpdated,
                                                    unitMetricK8sStatefulsetPodUpdated);
}

/**
  Deprecated, use @code k8s.statefulset.pod.ready @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.statefulset.pod.ready @endcode.", "reason": "renamed",
  "renamed_to": "k8s.statefulset.pod.ready"} <p> This metric aligns with the @code readyReplicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sStatefulsetReadyPods =
    "k8s.statefulset.ready_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sStatefulsetReadyPods =
    "Deprecated, use `k8s.statefulset.pod.ready` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sStatefulsetReadyPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetReadyPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetReadyPods,
                                         descrMetricK8sStatefulsetReadyPods,
                                         unitMetricK8sStatefulsetReadyPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetReadyPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetReadyPods,
                                          descrMetricK8sStatefulsetReadyPods,
                                          unitMetricK8sStatefulsetReadyPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetReadyPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetReadyPods,
                                                   descrMetricK8sStatefulsetReadyPods,
                                                   unitMetricK8sStatefulsetReadyPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetReadyPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetReadyPods,
                                                    descrMetricK8sStatefulsetReadyPods,
                                                    unitMetricK8sStatefulsetReadyPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

/**
  Deprecated, use @code k8s.statefulset.pod.updated @endcode instead.

  @deprecated
  {"note": "Replaced by @code k8s.statefulset.pod.updated @endcode.", "reason": "renamed",
  "renamed_to": "k8s.statefulset.pod.updated"} <p> This metric aligns with the @code updatedReplicas
  @endcode field of the <a
  href="https://kubernetes.io/docs/reference/generated/kubernetes-api/v1.34/#statefulsetstatus-v1-apps">K8s
  StatefulSetStatus</a>. <p> updowncounter
 */
OPENTELEMETRY_DEPRECATED static constexpr const char *kMetricK8sStatefulsetUpdatedPods =
    "k8s.statefulset.updated_pods";
OPENTELEMETRY_DEPRECATED static constexpr const char *descrMetricK8sStatefulsetUpdatedPods =
    "Deprecated, use `k8s.statefulset.pod.updated` instead.";
OPENTELEMETRY_DEPRECATED static constexpr const char *unitMetricK8sStatefulsetUpdatedPods = "{pod}";

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<int64_t>>
CreateSyncInt64MetricK8sStatefulsetUpdatedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64UpDownCounter(kMetricK8sStatefulsetUpdatedPods,
                                         descrMetricK8sStatefulsetUpdatedPods,
                                         unitMetricK8sStatefulsetUpdatedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::unique_ptr<metrics::UpDownCounter<double>>
CreateSyncDoubleMetricK8sStatefulsetUpdatedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleUpDownCounter(kMetricK8sStatefulsetUpdatedPods,
                                          descrMetricK8sStatefulsetUpdatedPods,
                                          unitMetricK8sStatefulsetUpdatedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncInt64MetricK8sStatefulsetUpdatedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateInt64ObservableUpDownCounter(kMetricK8sStatefulsetUpdatedPods,
                                                   descrMetricK8sStatefulsetUpdatedPods,
                                                   unitMetricK8sStatefulsetUpdatedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

OPENTELEMETRY_DEPRECATED static inline nostd::shared_ptr<metrics::ObservableInstrument>
CreateAsyncDoubleMetricK8sStatefulsetUpdatedPods(metrics::Meter *meter)
{
  OPENTELEMETRY_SUPPRESS_DEPRECATED_BEGIN
  return meter->CreateDoubleObservableUpDownCounter(kMetricK8sStatefulsetUpdatedPods,
                                                    descrMetricK8sStatefulsetUpdatedPods,
                                                    unitMetricK8sStatefulsetUpdatedPods);
  OPENTELEMETRY_SUPPRESS_DEPRECATED_END
}

}  // namespace k8s
}  // namespace semconv
OPENTELEMETRY_END_NAMESPACE
